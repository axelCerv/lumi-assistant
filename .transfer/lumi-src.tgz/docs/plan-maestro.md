# Lumi — Plan maestro y contexto del proyecto

> Versión 1.3 · 14 de octubre de 2026 · Autor: Axel · v1.1 agrega la personalización del avatar (sección 14); v1.2 agrega colores de marca, color de ojos, antena para todos y cabello corto; v1.3 agrega ropa y peinados por grupo (ella, él, trabajo, para todos) y 13 colores de ropa
> Documento de referencia para cualquier conversación o desarrollo sobre Lumi. Si algo aquí cambia, se actualiza este archivo.
> (Copia del documento del proyecto «Lumi Assistant». El avance contra este plan está en [ESTADO.md](ESTADO.md).)

---

## 1. Visión

Lumi es un asistente de escritorio (Windows y Mac) con un avatar flotante, siempre visible y arrastrable. Al hacer clic abre un panel con pendientes, próximas reuniones y un chat. Su diferencia: **tiene el "cerebro" del usuario** — todo su contexto de vida y trabajo — guardado **en la computadora del propio usuario**, en un vault de Obsidian, y alimentado automáticamente con las reuniones que graba Granola.

Principios:

1. **Local-first:** la información del usuario vive en su disco, en Markdown legible. Si Lumi desaparece, el usuario conserva todo.
2. **Costo de infraestructura ~$0 para Axel:** sin base de datos en la nube ni servidor propio en el MVP.
3. **Multi-IA:** el usuario elige Claude o Gemini (y se pueden añadir más).
4. **Tono amable**, proactivo pero no invasivo.

Funciones base (ya definidas antes): notas rápidas → recordatorios, etiquetas por cliente/proyecto, reuniones desde Gmail/Outlook, rutinas y detección de hábitos, chat con IA que conoce el contexto del usuario, y un avatar que cada quien personaliza (sección 14).

---

## 2. Decisiones clave

| Tema | Decisión | Por qué |
|---|---|---|
| Base de datos | **Vault de Obsidian (Markdown) = fuente de verdad** + índice SQLite local desechable | Costo $0, datos del usuario en su disco, legibles y editables en Obsidian |
| Búsqueda/memoria | SQLite con FTS5 (texto) + sqlite-vec (vectores), reconstruible desde el vault | Rápido, offline, sin servidor |
| Embeddings | Modelo local (transformers.js, p. ej. multilingual-e5-small) | Independiente del proveedor de IA (Claude no ofrece embeddings) y gratis |
| Reuniones | Granola graba → **Lumi sincroniza las notas al vault** como `.md` | Granola es sin bot; el vault conserva todo para siempre |
| IA | Capa de proveedores con **BYOK** (el usuario pone su propia API key) de Claude o Gemini | Axel no paga tokens; el usuario elige |
| Calendario | Google Calendar / Microsoft Graph vía OAuth | Saber reuniones futuras (Granola cubre el después) |
| App de escritorio | **Electron + TypeScript** | SDKs maduros de Anthropic, Google, MCP y SQLite en Node; ventana flotante transparente en ambos SO |
| Backend propio | Ninguno en MVP | Solo hace falta para cobrar o dar IA incluida (fase futura) |
| Obsidian | No necesita estar abierto: Lumi lee y escribe los archivos directamente | Menos dependencias; Obsidian es el "visor/editor" del usuario |

---

## 3. Arquitectura

```
┌──────────────────────── Computadora del usuario ────────────────────────┐
│                                                                          │
│  Granola (graba reuniones)        Obsidian (ve/edita el vault)           │
│        │  MCP / API                       ▲                              │
│        ▼                                  │ archivos .md                 │
│  ┌──────────────── LUMI (Electron) ───────┴──────────────┐               │
│  │  Granola Bridge ──► Vault Writer ──► VAULT (Markdown) │               │
│  │  Calendar Sync  ─┘        ▲              │ watcher     │               │
│  │                           │              ▼             │               │
│  │  Memory Engine ◄── Índice SQLite (FTS5 + vectores)     │               │
│  │       │            (en datos de la app, desechable)    │               │
│  │       ▼                                                │               │
│  │  Context Builder ──► LLM Provider (Claude | Gemini) ───┼──► API nube   │
│  │       ▲                                                │   (solo los   │
│  │  UI: avatar flotante · panel · chat · recordatorios    │   fragmentos  │
│  └────────────────────────────────────────────────────────┘   necesarios) │
└──────────────────────────────────────────────────────────────────────────┘
```

Flujo típico: el usuario pregunta "¿qué quedé con Acme la semana pasada?" → Context Builder busca en el índice (texto + semántica + recencia + enlaces) → arma un contexto con perfil + notas relevantes → lo envía al proveedor elegido → responde citando las notas (con enlace `obsidian://` para abrirlas).

---

## 4. El cerebro: estructura del vault

Lumi crea el vault en el onboarding (o se conecta a uno existente y solo agrega sus carpetas).

```
LumiVault/
├── 00-Inbox/                 # notas rápidas sin clasificar
├── 01-Diario/                # 2026-10-13.md (nota diaria)
├── 02-Reuniones/
│   └── 2026/10/              # 2026-10-13-revision-acme.md (desde Granola)
├── 03-Pendientes/            # pendientes sueltos; los demás viven dentro de cualquier nota
├── 04-Proyectos/             # una nota por proyecto
├── 05-Clientes/              # una nota por cliente
├── 06-Personas/              # una nota por persona (se enlaza desde reuniones)
├── 07-Rutinas/               # rutinas y hábitos
├── 08-Conocimiento/          # notas libres, ideas, referencias
├── 90-Lumi/
│   ├── perfil.md             # quién es el usuario (lo edita él, Lumi propone)
│   ├── preferencias.md       # cómo quiere que Lumi se comporte
│   ├── memoria/              # hechos aprendidos y confirmados, por tema
│   └── resumenes/            # resúmenes semanales/mensuales generados
├── 99-Plantillas/
└── .lumiignore               # carpetas que Lumi NUNCA lee ni envía a la IA
```

### Reglas de convivencia con el usuario
- Lumi **nunca sobrescribe** texto escrito por el usuario. Solo crea archivos nuevos, agrega secciones marcadas (`## Lumi · …`) o edita archivos con `source: lumi`.
- Todo archivo generado lleva frontmatter con `source` y `updated`.
- Una nota con `lumi: privado` en su frontmatter, o dentro de `.lumiignore`, jamás se envía a la IA.
- Los pendientes usan el formato del plugin Tasks para que funcionen igual en Obsidian:
  `- [ ] Enviar propuesta a [[Acme]] 📅 2026-10-15 #cliente/acme`

### Esquemas de frontmatter

**Reunión** (`02-Reuniones/`)
```yaml
---
type: reunion
source: granola
granola_id: not_1d3tmYTlCICgjy
title: Revisión trimestral Acme
date: 2026-10-13
start: 2026-10-13T10:00:00-06:00
duration_min: 45
attendees: ["[[Ana López]]", "[[Carlos Ruiz]]"]
cliente: "[[Acme]]"
proyecto: "[[Rediseño web]]"
tags: [reunion]
lumi_procesada: true
---
# Revisión trimestral Acme
## Resumen (Granola)
## Mis notas (Granola)
## Lumi · Pendientes detectados
- [ ] … 📅 …
## Lumi · Decisiones
## Transcripción
```

**Persona / Cliente / Proyecto**: `type`, `aliases`, `relacion` (persona), `estado` (proyecto), `tags`. Las reuniones se enlazan solas por backlinks.

**Memoria** (`90-Lumi/memoria/<tema>.md`): lista de hechos con fecha y origen:
`- 2026-10-13 · Prefiere reuniones por la mañana · (origen: [[2026-10-13]])`

---

## 5. Granola → Obsidian

Granola graba sin bot y genera notas mejoradas con IA + transcripción. Lumi actúa como **puente** y guarda cada reunión en `02-Reuniones/` con el esquema de arriba.

### Vías de acceso (estado a oct 2026)

| Vía | Plan Granola | Cómo | Valoración |
|---|---|---|---|
| **MCP oficial** (`https://mcp.granola.ai/mcp`) | Gratis (solo últimos 30 días) y de pago | OAuth en navegador (Dynamic Client Registration), sin API key. Herramientas: listar reuniones, obtenerlas, transcripción, carpetas, consulta | **Vía principal** — funciona para todos |
| **API pública** (`public-api.granola.ai/v1`) | Business (US$14/usuario/mes) o Enterprise | API key `grn_…` creada en Settings → Connectors → API keys. `GET /v1/notes`, `GET /v1/notes/{id}?include=transcript` | Vía preferida si el usuario paga Business: más simple y estable |
| Plugin de Obsidian "Granola Sync" (comunidad) | Cuenta Granola | El usuario lo instala; Lumi solo vigila la carpeta | Respaldo; reportado solo para macOS |
| Leer la caché local `cache-v3.json` | — | Archivo interno no documentado | **No usar**: frágil y a menudo sin notas |

### Estrategia
1. En onboarding, Lumi pide conectar Granola por OAuth (MCP). Si el usuario tiene API key de Business, puede pegarla en su lugar.
2. **Sincronización incremental** al abrir la app y cada ~15 min: trae reuniones nuevas desde la última fecha guardada; deduplica por `granola_id`.
3. Como el plan gratis solo expone ~30 días, **el vault se vuelve el historial permanente**: mientras Lumi sincronice al menos una vez al mes, nada se pierde.
4. Post-proceso con IA (opcional, configurable): extraer pendientes, decisiones, personas y cliente/proyecto; crear/enlazar notas en `06-Personas/` y `05-Clientes/`.
5. Antes de cada reunión del calendario, Lumi puede recordar: "¿Abro Granola para esta reunión?".

Toda fuente termina en el mismo contrato (archivo `.md` con frontmatter estándar), así cambiar de vía no afecta el resto de la app.

---

## 6. Capa de IA multi-proveedor

```ts
// packages/shared/llm.ts
interface LLMProvider {
  id: 'claude' | 'gemini';
  chat(req: {
    system: string;
    messages: Message[];
    tools?: ToolDef[];        // esquema JSON común
    stream?: boolean;
  }): AsyncIterable<ChatChunk>;
  countTokens?(text: string): Promise<number>;
}
```

- `ClaudeProvider` → `@anthropic-ai/sdk`. `GeminiProvider` → `@google/genai`.
- Las herramientas de Lumi (crear pendiente, buscar en vault, leer nota, agendar recordatorio, proponer recuerdo, cambiar apariencia) se definen una vez y cada proveedor las traduce a su formato de tool/function calling.
- **Modelos en configuración, nunca en el código.** Dos perfiles por proveedor: `rapido` (clasificar notas, extraer pendientes) y `inteligente` (chat, resúmenes). Ejemplos actuales: Claude Haiku / Sonnet; Gemini Flash-Lite / Flash. Gemini 2.5 se apaga el 16-oct-2026: usar la familia Gemini 3.
- API keys guardadas con el llavero del sistema (`safeStorage` de Electron), nunca en el vault.
- **Aviso de privacidad obligatorio en onboarding:** en el plan gratuito de la API de Gemini, Google puede usar entradas y salidas para mejorar sus modelos y pueden ser revisadas por personas. Para un "cerebro personal" se recomienda plan de pago o Claude.

---

## 7. Memoria y contexto (cómo piensa Lumi)

1. **Indexación:** un watcher (chokidar) detecta cambios en el vault → se trocea cada nota por encabezados → FTS5 + embeddings locales → SQLite en la carpeta de datos de la app (por dispositivo; no se sincroniza).
2. **Recuperación híbrida:** puntaje = texto + similitud semántica + recencia + cercanía en el grafo de enlaces (mismo cliente/persona/proyecto).
3. **Context Builder** (presupuesto de tokens fijo): `perfil.md` + `preferencias.md` + nota diaria de hoy + agenda de próximas 48 h + pendientes vencidos/próximos + top‑k fragmentos recuperados.
4. **Aprendizaje con confirmación:** tras conversaciones o reuniones, Lumi *propone* hechos nuevos ("¿Guardo que Acme renueva en enero?"). Solo los confirmados van a `90-Lumi/memoria/`. Evita que la memoria se llene de suposiciones.
5. **Resúmenes periódicos:** semanal y mensual en `90-Lumi/resumenes/`; mantienen el contexto largo barato.
6. **Hábitos:** a partir de notas diarias y pendientes completados (con hora), Lumi detecta patrones y sugiere rutinas; el usuario las acepta en `07-Rutinas/`.

---

## 8. Modelo de costos

| Concepto | Axel | Usuario |
|---|---|---|
| Base de datos / servidor | $0 | $0 |
| IA | $0 (BYOK) | Gemini con nivel gratis en modelos Flash, o pago por uso de Claude/Gemini |
| Obsidian | — | Gratis |
| Granola | — | Basic gratis (historial limitado) o Business US$14/mes |
| Sincronizar entre dispositivos | — | Opcional y a elección: iCloud, Syncthing, Git u Obsidian Sync |
| Firma de código | Apple Developer (≈US$99/año) + certificado Windows (verificar precio) | — |
| Actualizaciones | GitHub Releases + electron-updater ($0) | — |

Opción futura de negocio: "Lumi Pro" con IA incluida (Axel paga tokens y cobra suscripción). Requiere backend mínimo (licencias + proxy de IA); no forma parte del MVP.

---

## 9. Stack técnico

- **Desktop:** Electron, TypeScript, Vite, React (reutilizar el mockup `Asistente flotante.html`).
- **Empaquetado:** electron-builder (.dmg / .exe con NSIS), electron-updater.
- **Vault:** `gray-matter` (frontmatter), `remark` (Markdown), `chokidar` (watcher).
- **Índice:** `better-sqlite3` + FTS5 + `sqlite-vec`; embeddings con `@huggingface/transformers`.
- **IA:** `@anthropic-ai/sdk`, `@google/genai`.
- **Granola:** `@modelcontextprotocol/sdk` (cliente MCP por Streamable HTTP + OAuth) y `fetch` para la API REST.
- **Calendario:** Google Calendar API, Microsoft Graph.
- **Validación:** `zod` para esquemas de frontmatter y configuración.
- **Programación de recordatorios:** scheduler propio en el proceso principal + notificaciones nativas.

### Estructura del repositorio
```
LUMI/                              (~/Documents/PROGRAMACION/LUMI)
├── apps/desktop/
│   ├── src/main/
│   │   ├── vault/        # leer/escribir, plantillas, watcher, reglas de no-sobrescritura
│   │   ├── index/        # sqlite, fts, vectores, embeddings
│   │   ├── llm/          # provider.ts, claude.ts, gemini.ts, tools.ts
│   │   ├── granola/      # mcp-client.ts, api-client.ts, mapper.ts, sync.ts
│   │   ├── calendar/     # google.ts, microsoft.ts
│   │   ├── memory/       # context-builder.ts, extractor.ts, summaries.ts, habits.ts
│   │   ├── scheduler/    # recordatorios y notificaciones
│   │   └── secrets/      # safeStorage
│   ├── src/preload/
│   └── src/renderer/     # avatar flotante, panel, chat, onboarding, ajustes, apariencia
├── packages/shared/      # tipos, esquemas zod, interfaz LLMProvider, catálogo del avatar
├── templates/vault/      # estructura y plantillas iniciales del vault
└── docs/
```

---

## 10. Onboarding del usuario

1. Bienvenida y explicación: "tu información se queda en tu computadora". Ahí mismo, «Elige tu Lumi» (la clásica o uno de los personajes base).
2. Elegir o crear vault (botón para descargar Obsidian si no lo tiene).
3. Elegir IA: Claude o Gemini → pegar API key → prueba de conexión → aviso de privacidad.
4. Conectar calendario (Google u Outlook).
5. Conectar Granola: botón de descarga + conexión OAuth (o API key Business) + aviso de consentimiento de grabación.
6. Mini entrevista para crear `perfil.md` (nombre, trabajo, clientes, proyectos, rutinas).
7. Primer sync e indexado con barra de progreso.

---

## 11. Roadmap

**Fase 0 — Validación técnica (1 semana)**
- [ ] OAuth del MCP de Granola desde Electron (redirect loopback) y listar reuniones
- [ ] Llamada básica a Claude y a Gemini con la misma interfaz
- [ ] Ventana flotante transparente always-on-top en Mac y Windows
- [ ] Leer/escribir un vault de prueba e indexarlo con FTS5

**Fase 1 — MVP local**
- [ ] Avatar + panel (desde el mockup)
- [ ] Onboarding: vault + proveedor de IA
- [ ] Notas rápidas → Inbox; IA las convierte en pendientes con fecha y etiquetas
- [ ] Chat con contexto (FTS + perfil + pendientes)
- [ ] Recordatorios con notificaciones nativas
- [ ] Personalización del avatar: personajes, editor, cambios por chat (sección 14)

**Fase 2 — Reuniones**
- [ ] Calendario Google/Outlook
- [ ] Granola Bridge (MCP + API) → `02-Reuniones/`
- [ ] Post-proceso: pendientes, decisiones, personas, clientes

**Fase 3 — Memoria profunda**
- [ ] Embeddings locales + búsqueda híbrida
- [ ] Propuesta y confirmación de hechos de memoria
- [ ] Resúmenes semanales/mensuales
- [ ] Detección de hábitos y rutinas

**Fase 4 — Distribución**
- [ ] Firma y notarización (Mac), firma Windows
- [ ] Auto-actualización
- [ ] Landing y documentación de usuario

**Fase 5 — Opcional**
- [ ] Lumi Pro con IA incluida (backend mínimo)
- [ ] Más proveedores (OpenAI, modelos locales con Ollama)

---

## 12. Riesgos y puntos por validar

- **Cliente MCP de Granola desde app propia:** la documentación orienta a Claude/Cursor; confirmar en Fase 0 que el registro dinámico de OAuth funciona con Lumi. Plan B: API key (Business) o plugin de Obsidian.
- **Límites del plan gratis de Granola:** fuentes externas se contradicen (historial de 30 días vs. tope de reuniones). Verificar en la página oficial antes de prometer algo al usuario.
- **Granola en Windows:** algunas fuentes lo marcan como beta; el plugin de Obsidian se reporta solo para macOS → en Windows depender de MCP/API.
- **Cambios de API/modelos:** mantener modelos y endpoints en configuración; Gemini cambia de generación con frecuencia.
- **Conflictos al editar:** escribir con archivos temporales + renombrado atómico; respetar ediciones del usuario.
- **Privacidad:** solo enviar fragmentos necesarios; respetar `.lumiignore` y `lumi: privado`; advertir del nivel gratis de Gemini.
- **Consentimiento de grabación:** el usuario es responsable de avisar a los participantes; Lumi lo recuerda en onboarding.

---

## 13. Convenciones

- Idioma de la app y del vault: español.
- Fechas ISO (`YYYY-MM-DD`), zona horaria del sistema.
- Nombres de archivo de reunión: `YYYY-MM-DD-titulo-en-kebab.md`.
- Enlaces internos siempre con `[[Nombre]]` para que funcione el grafo de Obsidian.

---

## 14. Personalización del avatar

Lumi es una **esferita que flota**: silueta propia, redonda, con bracitos y sombra de flotar. Cada usuario la viste a su gusto. El diseño visual completo está en el lienzo «Lumi — Personalización» (plan, personajes base, guardarropa y editor).

### Principios
- **La esfera manda:** ninguna pieza cambia el contorno redondo. Cabello y ropa son pequeños y van pegados al cuerpo.
- **Zonas:** el cabello vive arriba (y 26–76), la ropa abajo (y 132–176) y la franja de la cara queda libre, salvo los lentes.
- **Femenino y masculino son puntos de partida, no candados:** la base solo cambia pestañas y grosor de cejas. Cualquier pieza sirve en cualquier base.
- **Hermanos de Lumi:** todos los personajes comparten los ojos grandes con brillo, los cachetes redondos y la antena de la Lumi clásica. Así se ven tiernos y de la misma familia.
- **Colores de cuerpo dentro de la marca:** los colores "Lumi" salen de la paleta de la app (índigo, sol, coral, menta…). Los tonos de piel son opcionales.
- **Los estados de ánimo solo tocan la cara** (reposo, pendientes, hablando, reunión, pensando, arrastrando) y nunca rompen la ropa.
- **Diseño propio:** no se imitan personajes con marca registrada.

### Lienzo y capas
SVG en un lienzo de 200×200 con la esfera en (100,112) y radio 62. Orden de dibujo, de atrás hacia adelante:

1. Sombra de flotar
2. Detrás: capa y antena
3. Cuerpo: bracitos, esfera y brillo
4. Prenda
5. Cara según el estado
6. Vello facial
7. Cabello
8. Lentes
9. Accesorio de cabeza

### Catálogo v1.2
Las piezas de cabello, ropa y accesorios llevan un grupo: **Para ella**, **Para él**, **Trabajo** o **Para todos**. El editor las muestra separadas, con el grupo de la base elegida primero, y el modo sorpresa respeta la base. Es solo una guía visual: cualquier pieza sirve en cualquier base.

| Capa | Opciones | Colores |
|---|---|---|
| Cuerpo · colores Lumi | morada clásica, lila, rosa, rojo, coral, sol, menta, cielo, noche (tonos de la marca) | — |
| Cuerpo · tonos de piel | clara, media, morena, morena oscura | — |
| Ojos | estilo Lumi para todos: blanco grande, iris, pupila y brillo | negros, cafés, miel, verdes, azules, violeta |
| Antena | sí / no (se esconde sola con gorra, gorro, boina, casco o gorro de chef) | — |
| Base | femenina, masculina, neutral | — |
| Cabello · ella | fleco, bob, cola de caballo, coletas, trenzas, chongo, rizos | negro, castaño, rubio, pelirrojo, lila |
| Cabello · él | corto, raya de lado, picos, copete, rizado corto, rapado, mohicano | los mismos |
| Cabello · todos | sin cabello, mechón | los mismos |
| Vello facial | ninguno, barba, bigote | el del cabello |
| Ropa · ella | blusa, vestido, overol | 13 colores de ropa |
| Ropa · él | camisa, camisa y corbata, corbatín, jersey (con número) | 13 colores de ropa |
| Ropa · trabajo | bata, delantal, chaleco reflejante | 13 colores de ropa |
| Ropa · todos | sin ropa, playera, rayas, bufanda, capa | 13 colores de ropa |
| Lentes | ninguno, redondos, cuadrados, ojo de gato, de sol | negro, carey, índigo, dorado |
| Accesorio · todos | ninguno, gorra, gorro, audífonos, moño, boina | 13 colores de ropa |
| Accesorio · trabajo | casco de obra, gorro de chef (siempre blanco) | 13 colores de ropa |

Colores de ropa y accesorios, en tonos de la marca más blanco y negro: índigo, lila, cielo, verde azulado, menta, rosa, rojo, coral, naranja, mostaza, blanco, grafito y negro. La ropa blanca lleva un borde suave, y sobre ropa clara los detalles (botones, número) van oscuros.

Cada color de cuerpo define su color de cachetes y si la boca y las cejas van oscuras (cuerpos claros) o blancas (cuerpos oscuros).

Personajes base. Todos son "hermanos" de Lumi, con colores de la marca:
- **Lumi:** la clásica, morada con antena. Es la que trae la app por defecto.
- **Femeninas:** Luz (rosa, coletas, vestido, lentes redondos), Itzel (lila, cola de caballo, blusa, moño) y Maya (menta, rizos, overol, audífonos).
- **Masculinos:** Leo (cielo, picos, jersey), Diego (noche, raya de lado, camisa y corbata, lentes cuadrados) y Andrés (rojo, cabello corto, barba, chaleco reflejante y casco).

### Datos
Se guarda en `settings.avatar` dentro de `configuracion.json`, en la carpeta de datos de la app (no en el vault):

```json
{
  "base": "femenina", "cuerpo": "rosa", "ojos": "cafe", "antena": true,
  "cabello": "coletas", "cabelloColor": "castano", "vello": "ninguno",
  "prenda": "bufanda", "prendaColor": "indigo",
  "lentes": "redondos", "lentesColor": "negro",
  "accesorio": "ninguno", "accesorioColor": "mostaza",
  "reunion": null
}
```

- Se valida con zod: si un id no existe, ese campo vuelve a su valor por defecto y el resto se conserva.
- Migración: las configuraciones viejas con `accesorio: "antena"` pasan a `antena: true` sin perder nada.
- `reunion` es la ropa formal que Lumi se pone sola cuando hay una reunión por empezar. Se elige según la base (`formalFor`): blusa para ella, camisa y corbata para él, corbatín para la neutral. Con `null` está apagado.

### Dónde vive en la app
- **Onboarding:** en la bienvenida, «Elige tu Lumi» muestra los 7 personajes.
- **Ajustes → Apariencia** (o clic en la carita del inicio): editor con vista previa en vivo. Tiene los personajes, pestañas por capa (Cuerpo: colores Lumi, tonos de piel y ojos · Cabello · Ropa · Lentes · Extras: antena y accesorio). Cabello, ropa y accesorios aparecen separados en «Para ella», «Para él», «Trabajo» y «Para todos». Además tiene el botón «Sorpréndeme» y el interruptor «Ropa formal en reuniones».
- **Clic derecho en el avatar flotante:** muestra Abrir menú · Cambiar mi look… · Platicar con Lumi · Esconder a Lumi. El ícono de la barra también tiene «Cambiar el look de Lumi…».
- **Chat:** el usuario lo pide con palabras («ponte lentes de sol») y la IA usa `cambiar_apariencia`. El chat muestra el cambio con un botón «Deshacer».

### Contexto para la IA
- La sección «Ahora» del contexto incluye `Tu apariencia actual (Lumi): <describeAvatar>`.
- Reglas del prompt de sistema:
  - Solo cambia su look cuando el usuario lo pide.
  - Si piden algo que no existe, ofrece lo más parecido.
  - Puede mencionar su look con naturalidad, sin insistir.
- Herramienta `cambiar_apariencia`: recibe solo los campos que cambian, limitados a los enums del catálogo. La app valida con `applyAvatarPatch`, guarda y redibuja. La IA nunca escribe archivos.

### Archivos en el código
| Archivo | Qué hace |
|---|---|
| `packages/shared/src/avatar.ts` | Catálogo, esquema zod, personajes, `applyAvatarPatch`, `describeAvatar` y `avatarCatalogText` |
| `apps/desktop/src/renderer/src/components/LumiFace.tsx` | Dibuja a Lumi por capas y estados |
| `apps/desktop/src/renderer/src/panel/Appearance.tsx` | Editor de apariencia |
| `apps/desktop/src/renderer/src/panel/Onboarding.tsx` | «Elige tu Lumi» |
| `apps/desktop/src/renderer/src/avatar/main.tsx` | Avatar flotante: aplica la prenda de reunión y el clic derecho |
| `apps/desktop/src/main/llm/tools.ts` · `agent.ts` | Herramienta `cambiar_apariencia` y reglas |
| `apps/desktop/src/main/windows.ts` | Menú del clic derecho (`avatarMenu`, `showPanelView`) |
| `apps/desktop/test/avatar.test.ts` · `avatar-tool.test.ts` | Pruebas |

### Agregar una pieza nueva
1. Dibujarla en el lienzo de 200×200 respetando las zonas, con un solo color variable y sombras de negro translúcido.
2. Agregar su id, nombre y grupo (`ella`, `el`, `trabajo` o `todos`) al catálogo en `avatar.ts`. Desde ahí llega al esquema, al editor y a la herramienta de la IA.
3. Dibujarla en `LumiFace.tsx`, en la capa que le toca.
4. Probarla en los 7 personajes y a 64 px, y correr `npm test`.

### Siguientes pasos
- **Más estados de cara:** dormida de noche y festejo al completar pendientes; gorro de dormir automático en la noche.
- **Piezas desbloqueables** con rachas de rutinas, sin bloquear nunca lo básico.
- **Paquetes de temporada:** Día de Muertos y Navidad.
