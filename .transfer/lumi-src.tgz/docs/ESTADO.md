# Estado de Lumi (v0.2.0 · 14 de octubre de 2026)

Comparación del roadmap del [plan maestro](plan-maestro.md) contra lo que está construido y verificado.

**Leyenda:**
- ✅ Hecho y probado (pruebas automáticas o la app corriendo).
- 🟡 Hecho, pero falta probarlo con tu cuenta o tu sistema.
- ⏳ Requiere algo de tu parte.

## Fase 0 — Validación técnica
| Tarea | Estado | Notas |
|---|---|---|
| OAuth del MCP de Granola (loopback) y listar reuniones | 🟡 | Usa el registro dinámico de cliente con retorno a `127.0.0.1:47821`. Probar con tu cuenta: *Ajustes → Granola → Probar conexión* muestra las herramientas del servidor. |
| Claude y Gemini con la misma interfaz | ✅ | Probado contra servidores simulados: streaming, herramientas y firmas de pensamiento de Gemini 3. Falta una prueba con claves reales. |
| Ventana flotante transparente siempre encima | ✅ | Probado en Linux: el avatar se arrastra, la burbuja se coloca a su lado y el panel se abre y cierra. Falta verlo en Mac y Windows. |
| Leer/escribir un vault e indexarlo con FTS5 | ✅ | 36 pruebas cubren las reglas de escritura, el índice, `.lumiignore` y `lumi: privado`. |

## Fase 1 — MVP local
| Tarea | Estado |
|---|---|
| Avatar + panel (desde el mockup) | ✅ |
| Onboarding: vault + proveedor de IA (7 pasos) | ✅ |
| Notas rápidas → Inbox; la IA las convierte en pendientes con fecha y etiquetas | ✅ Sin IA funciona con el lector local. |
| Chat con contexto (FTS + perfil + pendientes) | ✅ (con IA simulada) |
| Recordatorios con notificaciones nativas | ✅ Burbuja probada; la notificación del sistema depende de los permisos de tu SO. |
| Personalización del avatar (plan §14) | ✅ 13 colores de cuerpo (9 de la marca y 4 tonos de piel), 6 colores de ojos, antena para todos, 16 peinados y 15 prendas separados en ella, él, trabajo y para todos, 8 accesorios (casco y gorro de chef incluidos), 13 colores de ropa, 7 personajes estilo Lumi, editor, «Elige tu Lumi», cambios por chat con «Deshacer», ropa formal automática en reuniones y clic derecho «Cambiar mi look». 18 pruebas. Falta verlo en tu Mac. |

## Fase 2 — Reuniones
| Tarea | Estado |
|---|---|
| Calendario Google/Outlook | 🟡 El código está listo, pero el OAuth requiere tus IDs de cliente (README). El enlace iCal funciona ya y está probado, incluidos los eventos que se repiten. |
| Granola Bridge (MCP + API) → `02-Reuniones/` | 🟡 El formato y la deduplicación están probados. La lectura de la respuesta del MCP es flexible (JSON, XML o texto); falta confirmarla con datos reales. |
| Post-proceso: pendientes, decisiones, personas, clientes | 🟡 Usa el perfil rápido con JSON; falta probarlo con una reunión real. |

## Fase 3 — Memoria profunda
| Tarea | Estado |
|---|---|
| Embeddings locales + búsqueda híbrida | ✅ sqlite-vec probado con vectores simulados. El modelo real se descarga de Hugging Face la primera vez (en este entorno no había acceso, falta verlo en tu Mac). |
| Propuesta y confirmación de hechos de memoria | ✅ |
| Resúmenes semanales y mensuales | 🟡 Los periodos y la escritura están probados; falta probarlos con IA real. |
| Detección de hábitos y rutinas | ✅ |

## Fase 4 — Distribución (preparada)
| Tarea | Estado |
|---|---|
| Empaquetado `.dmg` / `.exe` | ✅ Configurado con electron-builder; el paquete de Linux se generó y corrió sin errores. |
| Firma y notarización (Mac), firma en Windows | ⏳ Se activa sola si agregas tus certificados como *secrets* (README). |
| Auto-actualización | 🟡 electron-updater desde GitHub Releases; funciona en cuanto publiques un release. |
| Landing y documentación de usuario | ⏳ El README cubre la instalación y el uso. |

## Decisiones tomadas al construir
- **La interfaz llama al proceso principal y nunca a la IA directo.** Las claves no salen del proceso principal y se cifran con `safeStorage`.
- **Los embeddings corren en una ventana oculta (WASM), no con onnxruntime nativo.** Así se evitan módulos nativos difíciles de empaquetar en Mac (universal) y Windows.
- **Hora de los avisos:** se usa `⏰ HH:MM` antes de `📅`. El plugin Tasks no tiene hora y así sigue reconociendo la fecha.
- **Snooze sin tocar tus notas:** se guarda en el estado interno de Lumi, no en tus notas.
- **Notas del usuario:** al agregar secciones `## Lumi · …`, el encabezado YAML se conserva byte por byte.
- **Calendario por iCal además del OAuth:** permite usar el calendario hoy mismo, sin registrar apps en Google ni en Microsoft.
- **Apariencia en la configuración, no en el vault:** es preferencia de la app y no contexto del usuario. La IA solo la cambia con la herramienta validada.
- **La versión Tauri anterior quedó en `_version-tauri/`.** Se puede borrar.
