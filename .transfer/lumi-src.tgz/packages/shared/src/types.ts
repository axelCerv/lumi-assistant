/** Tipos de dominio compartidos entre el proceso principal y la interfaz. */
import type { AvatarConfig } from "./avatar.ts";

export type TagKind = "cliente" | "proyecto";

export interface Tag {
  name: string;
  kind: TagKind;
}

/** Un pendiente leído del vault (formato del plugin Tasks de Obsidian). */
export interface Task {
  /** Identificador estable: archivo + texto (sobrevive si la línea se mueve). */
  key: string;
  path: string;
  line: number;
  raw: string;
  text: string;
  done: boolean;
  /** AAAA-MM-DD (📅) */
  due: string | null;
  /** HH:MM (⏰, extensión de Lumi) */
  time: string | null;
  /** Fecha y hora efectiva del aviso (ISO) o null si no tiene fecha. */
  remindAt: string | null;
  doneDate: string | null;
  tags: Tag[];
  otherTags: string[];
  links: string[];
  /** Viene de una nota marcada como privada: nunca se envía a la IA. */
  private: boolean;
  /** El archivo es de Lumi (se puede borrar la línea sin tocar texto del usuario). */
  lumiFile: boolean;
}

export interface TaskDraft {
  title: string;
  /** AAAA-MM-DD */
  date: string | null;
  /** HH:MM */
  time: string | null;
  tags: Tag[];
  contact: string | null;
  original?: string;
  reason?: string | null;
}

export interface Meeting {
  id: string;
  title: string;
  start: string;
  end: string;
  allDay: boolean;
  location: string | null;
  link: string | null;
  calendar: string;
  source: "google" | "microsoft" | "ics";
  attendees: string[];
}

export interface Routine {
  path: string;
  title: string;
  /** 0 = domingo … 6 = sábado */
  days: number[];
  time: string;
  active: boolean;
  lumiFile: boolean;
}

export interface RoutineSuggestion {
  key: string;
  title: string;
  days: number[];
  time: string;
  reason: string;
}

export interface Entity {
  name: string;
  kind: "cliente" | "proyecto" | "persona";
  path: string;
  slug: string;
}

export interface MemoryFact {
  /** Tema = archivo dentro de 90-Lumi/memoria/ */
  topic: string;
  date: string;
  text: string;
  origin: string | null;
  path: string;
  line: number;
}

export interface FactProposal {
  id: string;
  text: string;
  topic: string;
  origin: string | null;
  createdAt: string;
}

export interface SummaryInfo {
  path: string;
  title: string;
  kind: "semanal" | "mensual";
  date: string;
}

export interface SearchHit {
  path: string;
  title: string;
  heading: string | null;
  snippet: string;
  score: number;
}

export interface ChatSource {
  path: string;
  title: string;
}

export interface ChatAction {
  kind: "pendiente" | "recuerdo" | "apariencia";
  label: string;
  detail?: string;
  /** Para pendientes: key de la tarea creada (para deshacer). */
  taskKey?: string;
  /** Para recuerdos: id de la propuesta. */
  proposalId?: string;
  /** Para apariencia: cómo se veía Lumi antes del cambio (para deshacer). */
  lookBefore?: AvatarConfig;
  state?: "pendiente" | "hecho" | "descartado";
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  at: string;
  sources?: ChatSource[];
  actions?: ChatAction[];
  error?: boolean;
}

export type BubbleKind = "recordatorio" | "reunion" | "rutina" | "sugerencia" | "hola" | "resumen" | "granola";

export interface BubblePayload {
  kind: BubbleKind;
  text: string;
  time: string;
  tags?: Tag[];
  taskKey?: string;
  routinePath?: string;
  meetingId?: string;
  link?: string | null;
  notePath?: string;
  suggestion?: RoutineSuggestion;
  cta?: string;
  granola?: boolean;
  side?: "left" | "right";
}

export interface ServiceStatus {
  ok: boolean;
  label: string;
  detail?: string | null;
}

export interface IndexStatus {
  notes: number;
  chunks: number;
  embedded: number;
  indexing: boolean;
  progress: number;
  semantic: "apagada" | "cargando" | "lista" | "error";
  semanticDetail?: string | null;
}

/** Lo que la interfaz necesita para dibujarse. Se envía completo cada vez que cambia algo. */
export interface AppSnapshot {
  settings: import("./schemas.ts").Settings;
  vaultName: string | null;
  keys: { claude: boolean; gemini: boolean; granola: boolean };
  tasks: Task[];
  meetings: Meeting[];
  routines: Routine[];
  entities: Entity[];
  proposals: FactProposal[];
  index: IndexStatus;
  calendars: { google: ServiceStatus; microsoft: ServiceStatus; ics: (ServiceStatus & { id: string })[]; updatedAt: string | null };
  granola: ServiceStatus & { lastSync: string | null; count: number };
  oauthConfigured: { google: boolean; microsoft: boolean };
  update: { available: boolean; version: string | null; downloaded: boolean };
  bubbleOpen: boolean;
  appVersion: string;
}
