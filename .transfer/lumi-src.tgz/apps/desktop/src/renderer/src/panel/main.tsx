import React, { useEffect, useState } from "react";
import ReactDOM from "react-dom/client";
import "../styles.css";
import { DEFAULT_AVATAR } from "@lumi/shared";
import { AvatarLook } from "../components/LumiFace";
import { lumi, useNow, useSnapshot } from "../lib/api";
import { Appearance } from "./Appearance";
import { Chat } from "./Chat";
import { Home } from "./Home";
import { Memory } from "./Memory";
import { NoteEditor } from "./NoteEditor";
import { Onboarding } from "./Onboarding";
import { Routines } from "./Routines";
import { Settings } from "./Settings";

export type View =
  | { name: "home" }
  | { name: "note"; text?: string; taskKey?: string }
  | { name: "chat" }
  | { name: "routines" }
  | { name: "settings" }
  | { name: "memory" }
  | { name: "appearance" };

function Panel() {
  const snap = useSnapshot();
  const now = useNow();
  const [view, setView] = useState<View>({ name: "home" });

  // Clic derecho en el avatar o en la bandeja: abrir una vista concreta
  useEffect(() => lumi.on("panel-view", (name) => setView({ name } as View)), []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      setView((v) => {
        if (v.name === "home") {
          void lumi.hidePanel();
          return v;
        }
        return v.name === "appearance" ? { name: "settings" } : { name: "home" };
      });
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const home = () => setView({ name: "home" });
  let content: React.ReactNode = null;
  if (snap && !snap.settings.onboarded) content = <Onboarding snap={snap} />;
  else if (snap) {
    if (view.name === "home") content = <Home snap={snap} go={setView} now={now} />;
    else if (view.name === "note") content = <NoteEditor key={view.taskKey ?? view.text} snap={snap} text={view.text} taskKey={view.taskKey} onDone={home} />;
    else if (view.name === "chat") content = <Chat snap={snap} go={setView} />;
    else if (view.name === "routines") content = <Routines snap={snap} go={setView} />;
    else if (view.name === "settings") content = <Settings snap={snap} go={setView} />;
    else if (view.name === "memory") content = <Memory snap={snap} go={setView} />;
    else if (view.name === "appearance") content = <Appearance snap={snap} go={setView} />;
  }

  return (
    <div style={{ padding: 12, width: "100vw", height: "100vh" }}>
      <main
        style={{
          width: "100%",
          height: "100%",
          background: "#fff",
          borderRadius: 24,
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
          boxShadow: "0 8px 24px rgba(10, 11, 30, 0.28), 0 0 0 1px rgba(30,32,51,0.08)",
          animation: "lumi-pop 0.16s ease-out",
        }}
      >
        <AvatarLook.Provider value={snap?.settings.avatar ?? DEFAULT_AVATAR}>{content}</AvatarLook.Provider>
      </main>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <Panel />
  </React.StrictMode>,
);
