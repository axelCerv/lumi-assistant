/** Onboarding en 7 pasos: bienvenida, vault, IA, calendario, Granola, entrevista e indexado. */
import { useEffect, useState } from "react";
import { PRESETS, sameAvatar, type AppSnapshot } from "@lumi/shared";
import { LumiFace } from "../components/LumiFace";
import { IconClose, IconFolder } from "../components/Icons";
import { lumi } from "../lib/api";
import { AIForm, CalendarForm, GranolaForm, Msg } from "./connect";

const STEPS = ["Bienvenida", "Tu vault", "Inteligencia", "Calendario", "Granola", "Conóceme", "Listo"];

export function Onboarding({ snap }: { snap: AppSnapshot }) {
  const step = Math.min(snap.settings.onboardingStep, STEPS.length - 1);
  const goTo = (n: number) => lumi.updateSettings({ onboardingStep: n });
  const next = () => goTo(step + 1);
  const back = () => goTo(Math.max(0, step - 1));

  return (
    <>
      <div className="row" style={{ padding: "14px 14px 0 18px", gap: 10 }}>
        <div className="grow" style={{ display: "flex", gap: 4 }} aria-label={`Paso ${step + 1} de ${STEPS.length}`}>
          {STEPS.map((s, i) => (
            <span key={s} title={s} style={{ flex: 1, height: 4, borderRadius: 2, background: i <= step ? "var(--indigo)" : "var(--line-strong)" }} />
          ))}
        </div>
        <button type="button" className="icon-btn plain" aria-label="Cerrar (sigues después)" onClick={() => lumi.hidePanel()}>
          <IconClose size={18} />
        </button>
      </div>
      <div className="scroll" style={{ flex: 1, padding: "16px 22px 12px", display: "flex", flexDirection: "column", gap: 14 }}>
        {step === 0 && <Welcome snap={snap} />}
        {step === 1 && <VaultStep snap={snap} onDone={next} />}
        {step === 2 && (
          <>
            <StepTitle title="Elige tu IA" text="Lumi usa tu propia clave: tú eliges el proveedor y pagas solo lo que usas. Solo se envían los fragmentos necesarios para responder." />
            <AIForm snap={snap} compact />
          </>
        )}
        {step === 3 && (
          <>
            <StepTitle title="Conecta tu calendario" text="Para saber qué reuniones vienen y avisarte unos minutos antes." />
            <CalendarForm snap={snap} compact />
          </>
        )}
        {step === 4 && (
          <>
            <StepTitle title="Conecta Granola" text="Granola graba tus reuniones sin bot. Lumi guarda cada una en tu vault con resumen, pendientes y decisiones, para siempre." />
            <GranolaForm snap={snap} compact />
          </>
        )}
        {step === 5 && <Interview snap={snap} onDone={next} />}
        {step === 6 && <Indexing snap={snap} />}
      </div>
      {step !== 1 && step !== 5 && (
        <div className="row" style={{ padding: "12px 18px 16px", gap: 10, borderTop: "1px solid var(--line)" }}>
          {step > 0 && (
            <button type="button" className="btn btn-ghost btn-lg" onClick={back}>
              Atrás
            </button>
          )}
          <span className="grow" />
          {step === 6 ? (
            <button type="button" className="btn btn-primary btn-lg" onClick={() => lumi.finishOnboarding()}>
              ¡Empezar a usar Lumi!
            </button>
          ) : (
            <>
              {step >= 2 && step <= 4 && (
                <button type="button" className="btn btn-soft btn-lg" onClick={next}>
                  Más tarde
                </button>
              )}
              <button type="button" className="btn btn-primary btn-lg" onClick={next}>
                {step === 0 ? "Empezar" : "Siguiente"}
              </button>
            </>
          )}
        </div>
      )}
    </>
  );
}

function StepTitle({ title, text }: { title: string; text: string }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      <h1 style={{ margin: 0, fontFamily: "var(--display)", fontSize: 24, fontWeight: 700 }}>{title}</h1>
      <p style={{ margin: 0, fontSize: 14, lineHeight: 1.5, color: "var(--muted-strong)" }}>{text}</p>
    </div>
  );
}

function Welcome({ snap }: { snap: AppSnapshot }) {
  const look = snap.settings.avatar;
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", gap: 14, paddingTop: 10 }}>
      <div style={{ animation: "lumi-bob 3.2s ease-in-out infinite" }}>
        <LumiFace size={108} mood="hablando" shadow />
      </div>
      <h1 style={{ margin: 0, fontFamily: "var(--display)", fontSize: 28, fontWeight: 700 }}>¡Hola! Soy Lumi</h1>
      <div style={{ width: "100%", textAlign: "left" }}>
        <span id="elige-lumi" className="field-label">
          Elige tu Lumi
        </span>
        <div role="group" aria-labelledby="elige-lumi" style={{ display: "grid", gridTemplateColumns: `repeat(${PRESETS.length}, minmax(0, 1fr))`, gap: 4 }}>
          {PRESETS.map((pr) => {
            const on = sameAvatar(pr.look, look);
            return (
              <button
                key={pr.id}
                type="button"
                aria-pressed={on}
                aria-label={pr.name}
                title={pr.name}
                onClick={() => lumi.updateSettings({ avatar: pr.look })}
                style={{
                  aspectRatio: "1",
                  padding: 0,
                  borderRadius: 12,
                  background: on ? "var(--lavender)" : "#fff",
                  border: on ? "2px solid var(--indigo)" : "1px solid var(--line-strong)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <LumiFace size={36} look={pr.look} />
              </button>
            );
          })}
        </div>
        <span className="hint">Luego le cambias ropa, cabello y lentes en Ajustes → Apariencia.</span>
      </div>
      <p style={{ margin: 0, fontSize: 15, lineHeight: 1.55, color: "var(--muted-strong)" }}>
        Voy a flotar en tu pantalla para recordarte pendientes, avisarte de reuniones y ayudarte con tus rutinas.
      </p>
      <div style={{ padding: 14, borderRadius: 16, background: "var(--lavender)", textAlign: "left", fontSize: 14, lineHeight: 1.5 }}>
        <b>Tu información se queda en tu computadora.</b> Guardo todo en un vault de Obsidian: archivos Markdown que puedes leer y editar. Si un día dejas de usarme, conservas todo.
      </div>
    </div>
  );
}

function VaultStep({ snap, onDone }: { snap: AppSnapshot; onDone: () => void }) {
  const [mode, setMode] = useState<"crear" | "existente">("crear");
  const [path, setPath] = useState(snap.settings.vaultPath ?? "");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!path) lumi.defaultVaultPath().then(setPath);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  async function pick() {
    const p = await lumi.chooseFolder(mode === "crear" ? "¿Dónde creo tu vault?" : "Elige tu vault de Obsidian");
    if (p) setPath(mode === "crear" && !/LumiVault$/i.test(p) ? `${p}/LumiVault` : p);
  }

  async function confirm() {
    setBusy(true);
    const r = await lumi.setupVault(path, mode);
    setBusy(false);
    if (!r.ok) return setMsg({ ok: false, text: r.error ?? "No pude preparar el vault" });
    onDone();
  }

  return (
    <>
      <StepTitle title="Tu cerebro" text="Elige dónde vivirá tu información. Lumi crea sus carpetas (00-Inbox, 02-Reuniones, 05-Clientes…) sin tocar lo que ya tengas." />
      <div role="radiogroup" style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {(
          [
            ["crear", "Crear un vault nuevo", "Recomendado si aún no usas Obsidian"],
            ["existente", "Usar mi vault de Obsidian", "Lumi solo agrega sus carpetas"],
          ] as const
        ).map(([id, label, hint]) => (
          <button
            key={id}
            type="button"
            role="radio"
            aria-checked={mode === id}
            onClick={() => {
              setMode(id);
              if (id === "existente") setPath("");
              else lumi.defaultVaultPath().then(setPath);
            }}
            style={{ textAlign: "left", padding: "12px 14px", borderRadius: 14, border: mode === id ? "2px solid var(--indigo)" : "1px solid var(--line-strong)", background: mode === id ? "var(--lavender)" : "#fff", display: "flex", flexDirection: "column", gap: 2 }}
          >
            <span style={{ fontWeight: 700, fontSize: 14.5 }}>{label}</span>
            <span className="hint">{hint}</span>
          </button>
        ))}
      </div>
      <div className="row" style={{ gap: 8, padding: "10px 12px", borderRadius: 14, background: "var(--surface)" }}>
        <IconFolder size={18} />
        <span className="grow" style={{ fontSize: 13, overflowWrap: "anywhere" }}>{path || "Sin carpeta elegida"}</span>
        <button type="button" className="btn btn-soft" style={{ background: "#fff" }} onClick={pick}>
          Cambiar
        </button>
      </div>
      <span className="hint">
        ¿No tienes Obsidian? No es obligatorio, pero es la mejor forma de ver tu cerebro.{" "}
        <a href="#" onClick={(e) => (e.preventDefault(), lumi.openExternal("https://obsidian.md/download"))}>
          Descargar Obsidian
        </a>
      </span>
      <Msg m={msg} />
      <div className="row" style={{ gap: 10, marginTop: "auto" }}>
        <button type="button" className="btn btn-ghost btn-lg" onClick={() => lumi.updateSettings({ onboardingStep: 0 })}>
          Atrás
        </button>
        <span className="grow" />
        <button type="button" className="btn btn-primary btn-lg" disabled={!path || busy} onClick={confirm}>
          {busy ? "Preparando…" : mode === "crear" ? "Crear vault" : "Usar este vault"}
        </button>
      </div>
    </>
  );
}

function Interview({ snap, onDone }: { snap: AppSnapshot; onDone: () => void }) {
  const [a, setA] = useState({ name: snap.settings.userName, work: "", clients: "", projects: "", routines: "" });
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof a) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setA({ ...a, [k]: e.target.value });

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const r = await lumi.saveProfile(a);
    setBusy(false);
    if (!r.ok) return setMsg({ ok: false, text: r.error ?? "No pude guardar" });
    onDone();
  }

  const fields: [keyof typeof a, string, string, boolean][] = [
    ["name", "¿Cómo te llamo?", "Axel", false],
    ["work", "¿A qué te dedicas?", "Desarrollo web freelance y asesoría fiscal…", true],
    ["clients", "Tus clientes (separados por coma)", "Grupo Norte, Despacho Ruiz", false],
    ["projects", "Tus proyectos", "Rediseño web, Propuesta Q4", false],
    ["routines", "Rutinas que quieres cuidar (una por línea)", "Revisar correo 9:00\nCierre del día 18:30", true],
  ];

  return (
    <form onSubmit={save} style={{ display: "flex", flexDirection: "column", gap: 12, flex: 1 }}>
      <StepTitle title="Conóceme" text="Con esto escribo tu perfil en 90-Lumi/perfil.md, creo las notas de tus clientes y proyectos, y tus rutinas. Todo es editable." />
      {fields.map(([k, label, ph, multi]) => (
        <div key={k}>
          <label htmlFor={`p-${k}`} className="field-label">
            {label}
          </label>
          {multi ? (
            <textarea id={`p-${k}`} className="textarea" rows={2} placeholder={ph} value={a[k]} onChange={set(k)} />
          ) : (
            <input id={`p-${k}`} className="input" placeholder={ph} value={a[k]} onChange={set(k)} autoFocus={k === "name"} />
          )}
        </div>
      ))}
      <Msg m={msg} />
      <div className="row" style={{ gap: 10, marginTop: "auto", paddingTop: 6 }}>
        <button type="button" className="btn btn-ghost btn-lg" onClick={() => lumi.updateSettings({ onboardingStep: 4 })}>
          Atrás
        </button>
        <span className="grow" />
        <button type="submit" className="btn btn-primary btn-lg" disabled={busy}>
          {busy ? "Guardando…" : "Siguiente"}
        </button>
      </div>
    </form>
  );
}

function Indexing({ snap }: { snap: AppSnapshot }) {
  const ix = snap.index;
  const pct = ix.indexing ? Math.round(ix.progress * 100) : 100;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14, alignItems: "center", textAlign: "center", paddingTop: 10 }}>
      <LumiFace size={96} mood={ix.indexing ? "pensando" : "hablando"} shadow />
      <h1 style={{ margin: 0, fontFamily: "var(--display)", fontSize: 24, fontWeight: 700 }}>{ix.indexing ? "Leyendo tu vault…" : "¡Listo!"}</h1>
      <div style={{ width: "100%", height: 10, borderRadius: 5, background: "var(--line-strong)", overflow: "hidden" }} role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
        <div style={{ width: `${pct}%`, height: "100%", background: "var(--indigo)", transition: "width 0.3s" }} />
      </div>
      <p style={{ margin: 0, fontSize: 14, color: "var(--muted-strong)", lineHeight: 1.5 }}>
        {ix.notes} notas · {ix.chunks} fragmentos indexados
        {snap.settings.ai.semanticSearch && <><br />Búsqueda por significado: {ix.semantic === "lista" ? `${ix.embedded} de ${ix.chunks}` : ix.semantic === "cargando" ? "descargando el modelo (solo la primera vez)" : ix.semantic === "error" ? "no disponible; uso búsqueda por texto" : "en espera"}</>}
      </p>
      <div style={{ padding: 14, borderRadius: 16, background: "var(--lavender)", textAlign: "left", fontSize: 13.5, lineHeight: 1.5 }}>
        Arrástrame a donde no estorbe. Haz clic en mí para anotar algo o preguntarme. Te aviso de pendientes y reuniones con una burbuja.
      </div>
    </div>
  );
}
