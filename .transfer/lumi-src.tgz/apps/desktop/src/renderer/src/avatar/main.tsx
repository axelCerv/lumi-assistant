import { useRef, useState } from "react";
import ReactDOM from "react-dom/client";
import { DEFAULT_AVATAR, addDays, startOfDay } from "@lumi/shared";
import "../styles.css";
import { AvatarLook, LumiFace, type Mood } from "../components/LumiFace";
import { lumi, useNow, useSnapshot } from "../lib/api";

function Avatar() {
  const snap = useSnapshot();
  const now = useNow();
  const [dragging, setDragging] = useState(false);
  const press = useRef<{ x: number; y: number; dragging: boolean } | null>(null);

  const endOfToday = addDays(startOfDay(now), 1);
  const badge = snap ? snap.tasks.filter((t) => !t.done && t.remindAt && new Date(t.remindAt) < endOfToday).length : 0;
  const meetingSoon = !!snap?.meetings.some((m) => {
    if (m.allDay) return false;
    const diff = new Date(m.start).getTime() - now.getTime();
    return diff > -60_000 && diff < (snap.settings.meetingLeadMin ?? 10) * 60_000;
  });
  const thinking = !!snap?.index.indexing;
  const mood: Mood = dragging
    ? "arrastrando"
    : snap?.bubbleOpen
      ? "hablando"
      : meetingSoon
        ? "reunion"
        : thinking
          ? "pensando"
          : badge > 0
            ? "pendientes"
            : "reposo";
  // En reuniones, Lumi se pone sola la prenda que elegiste (si elegiste una).
  const saved = snap?.settings.avatar ?? DEFAULT_AVATAR;
  const look = meetingSoon && saved.reunion ? { ...saved, prenda: saved.reunion } : saved;

  return (
    <button
      type="button"
      aria-label={`Lumi, tu asistente${badge ? `: ${badge} pendientes hoy` : ""}. Clic para abrir el menú, arrastra para moverlo, clic derecho para más opciones`}
      title="Clic: abrir menú · Arrastra: mover · Clic derecho: cambiar look y más"
      style={{
        position: "fixed",
        inset: 0,
        width: "100%",
        height: "100%",
        padding: 0,
        border: 0,
        background: "transparent",
        cursor: dragging ? "grabbing" : "grab",
        touchAction: "none",
        outline: "none",
      }}
      onPointerDown={(e) => {
        if (e.button !== 0 || e.ctrlKey) return; // ctrl+clic en Mac = clic derecho
        e.currentTarget.setPointerCapture(e.pointerId);
        press.current = { x: e.screenX, y: e.screenY, dragging: false };
        void lumi.avatarPress();
      }}
      onPointerMove={(e) => {
        const p = press.current;
        if (!p || p.dragging) return;
        if (Math.hypot(e.screenX - p.x, e.screenY - p.y) > 4) {
          p.dragging = true;
          setDragging(true);
          void lumi.avatarDrag(true);
        }
      }}
      onPointerUp={() => {
        const p = press.current;
        press.current = null;
        if (!p) return;
        if (p.dragging) {
          setDragging(false);
          void lumi.avatarDrag(false);
        } else void lumi.togglePanel();
      }}
      onContextMenu={(e) => {
        e.preventDefault();
        press.current = null;
        void lumi.avatarMenu();
      }}
      onPointerCancel={() => {
        if (press.current?.dragging) void lumi.avatarDrag(false);
        press.current = null;
        setDragging(false);
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          void lumi.togglePanel();
        }
      }}
    >
      <span style={{ position: "absolute", left: 6, top: 10, display: "block", animation: dragging ? "none" : "lumi-bob 3.2s ease-in-out infinite" }}>
        <AvatarLook.Provider value={look}>
          <LumiFace size={84} mood={mood} shadow />
        </AvatarLook.Provider>
      </span>
      {badge > 0 && !snap?.bubbleOpen && (
        <span
          aria-hidden="true"
          style={{
            position: "absolute",
            right: 6,
            top: 14,
            minWidth: 22,
            height: 22,
            padding: "0 6px",
            borderRadius: 11,
            background: "var(--sun)",
            color: "var(--ink)",
            font: "700 12px/22px var(--font)",
            textAlign: "center",
            boxShadow: "0 0 0 3px rgba(51,55,90,0.9)",
          }}
        >
          {badge > 9 ? "9+" : badge}
        </span>
      )}
    </button>
  );
}

ReactDOM.createRoot(document.getElementById("root")!).render(<Avatar />);
