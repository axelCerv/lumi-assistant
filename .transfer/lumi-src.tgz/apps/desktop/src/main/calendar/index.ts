/** Junta las reuniones de todos los calendarios conectados (próximos 7 días). */
import type { Meeting, ServiceStatus } from "@lumi/shared";
import { getSettings } from "../settings";
import { googleEvents, microsoftEvents } from "./providers";
import { fetchIcs, parseIcs } from "./ics";
import { emitChanged, errorText } from "../util";

const DAYS_AHEAD = 7;

export interface CalendarState {
  meetings: Meeting[];
  google: ServiceStatus;
  microsoft: ServiceStatus;
  ics: (ServiceStatus & { id: string })[];
  updatedAt: string | null;
}

let state: CalendarState = {
  meetings: [],
  google: { ok: false, label: "Sin conectar" },
  microsoft: { ok: false, label: "Sin conectar" },
  ics: [],
  updatedAt: null,
};
let running: Promise<void> | null = null;

export function calendarState(): CalendarState {
  return state;
}

export function meetings(): Meeting[] {
  return state.meetings;
}

export function refreshCalendars(): Promise<void> {
  if (!running) running = doRefresh().finally(() => (running = null));
  return running;
}

async function doRefresh(): Promise<void> {
  const s = getSettings().calendars;
  const now = new Date();
  const from = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const to = new Date(from.getTime() + DAYS_AHEAD * 86400000);
  const all: Meeting[] = [];
  const next: CalendarState = { ...state, ics: [] };

  if (s.google.connected) {
    try {
      const list = await googleEvents(from, to);
      all.push(...list);
      next.google = { ok: true, label: s.google.email ? `Conectado · ${s.google.email}` : "Conectado", detail: `${list.length} eventos esta semana` };
    } catch (e) {
      next.google = { ok: false, label: "Error", detail: errorText(e) };
    }
  } else next.google = { ok: false, label: "Sin conectar" };

  if (s.microsoft.connected) {
    try {
      const list = await microsoftEvents(from, to);
      all.push(...list);
      next.microsoft = { ok: true, label: s.microsoft.email ? `Conectado · ${s.microsoft.email}` : "Conectado", detail: `${list.length} eventos esta semana` };
    } catch (e) {
      next.microsoft = { ok: false, label: "Error", detail: errorText(e) };
    }
  } else next.microsoft = { ok: false, label: "Sin conectar" };

  for (const src of s.ics.filter((x) => x.enabled)) {
    try {
      const list = parseIcs(await fetchIcs(src.url), src, from, to);
      all.push(...list);
      next.ics.push({ id: src.id, ok: true, label: src.name, detail: `${list.length} eventos esta semana` });
    } catch (e) {
      next.ics.push({ id: src.id, ok: false, label: src.name, detail: errorText(e) });
    }
  }

  // Quita duplicados (el mismo evento en dos fuentes)
  const seen = new Set<string>();
  next.meetings = all
    .sort((a, b) => a.start.localeCompare(b.start))
    .filter((m) => {
      const k = `${m.title.toLowerCase()}|${m.start}`;
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  next.updatedAt = new Date().toISOString();
  state = next;
  emitChanged();
}
