/**
 * Herramientas de Lumi para la IA. Se definen una vez (esquema JSON común) y cada
 * proveedor las traduce a su formato de "tool/function calling".
 */
import type { ChatAction, ChatSource, Meeting, Tag, TaskDraft, ToolCall, ToolDef } from "@lumi/shared";
import {
  ACCESSORIES,
  BODIES,
  COLORS,
  EYE_COLORS,
  FACIALS,
  FRAMES,
  GLASSES,
  HAIR_COLORS,
  HAIRS,
  OUTFITS,
  addDays,
  applyAvatarPatch,
  describeAvatar,
  startOfDay,
  whenLabel,
} from "@lumi/shared";
import { getSettings, updateSettings } from "../settings";
import type { Brain } from "../vault/brain";
import { proposeFact } from "../memory/facts";
import { errorText } from "../util";

export const LUMI_TOOLS: ToolDef[] = [
  {
    name: "buscar_en_vault",
    description:
      "Busca en las notas del usuario (reuniones, clientes, proyectos, diario, memoria) por texto y significado. Úsala para responder preguntas sobre lo que el usuario ha hablado, decidido o anotado.",
    parameters: {
      type: "object",
      properties: { consulta: { type: "string", description: "Qué buscar, en lenguaje natural" } },
      required: ["consulta"],
    },
  },
  {
    name: "leer_nota",
    description: "Lee el contenido completo de una nota del vault por su ruta o nombre (por ejemplo «02-Reuniones/2026/10/2026-10-13-revision-acme.md» o «Acme»).",
    parameters: {
      type: "object",
      properties: { nota: { type: "string", description: "Ruta o nombre de la nota" } },
      required: ["nota"],
    },
  },
  {
    name: "listar_pendientes",
    description: "Lista los pendientes del usuario. Filtro opcional por periodo y por cliente o proyecto.",
    parameters: {
      type: "object",
      properties: {
        periodo: { type: "string", enum: ["hoy", "atrasados", "semana", "todos"], description: "Periodo" },
        etiqueta: { type: "string", description: "Nombre de un cliente o proyecto (opcional)" },
      },
    },
  },
  {
    name: "proximas_reuniones",
    description: "Lista las reuniones del calendario de los próximos 7 días.",
    parameters: { type: "object", properties: {} },
  },
  {
    name: "crear_pendiente",
    description:
      "Crea un pendiente en el vault (con aviso si tiene fecha). Úsala cuando el usuario pida anotar algo o cuando acuerden algo con fecha.",
    parameters: {
      type: "object",
      properties: {
        titulo: { type: "string", description: "Acción corta que empieza con verbo en infinitivo" },
        fecha: { type: "string", description: "AAAA-MM-DD (opcional)" },
        hora: { type: "string", description: "HH:MM en 24 h (opcional)" },
        cliente: { type: "string", description: "Nombre del cliente (opcional)" },
        proyecto: { type: "string", description: "Nombre del proyecto (opcional)" },
        persona: { type: "string", description: "Persona relacionada (opcional)" },
      },
      required: ["titulo"],
    },
  },
  {
    name: "agendar_recordatorio",
    description: "Agenda un recordatorio a una fecha y hora concretas (Lumi avisará con su burbuja y una notificación).",
    parameters: {
      type: "object",
      properties: {
        titulo: { type: "string", description: "Qué recordar" },
        fecha: { type: "string", description: "AAAA-MM-DD" },
        hora: { type: "string", description: "HH:MM en 24 h" },
      },
      required: ["titulo", "fecha", "hora"],
    },
  },
  {
    name: "proponer_recuerdo",
    description:
      "Propone guardar en la memoria de Lumi un dato durable sobre el usuario, sus clientes, proyectos, personas, preferencias u horarios. El usuario lo confirmará. No propongas datos sensibles ni cosas que ya estén en la memoria.",
    parameters: {
      type: "object",
      properties: {
        hecho: { type: "string", description: "El dato en una frase, en tercera persona" },
        tema: { type: "string", description: "Tema para agruparlo (p. ej. el nombre del cliente, «Trabajo», «Preferencias»)" },
      },
      required: ["hecho"],
    },
  },
  {
    name: "cambiar_apariencia",
    description:
      "Cambia cómo se ve Lumi (la esferita flotante): ropa, cabello, lentes, accesorios o colores. Úsala SOLO cuando el usuario lo pida. Manda únicamente los campos que cambian. Si piden algo que no está en las opciones, ofrece lo más parecido en tu respuesta en lugar de llamarla.",
    parameters: {
      type: "object",
      properties: {
        cuerpo: {
          type: "string",
          enum: BODIES.map((x) => x.id),
          description: "Color del cuerpo. «clasica» es la Lumi morada original; lila, rosa, rojo, coral, sol, menta, cielo y noche son colores de la marca; clara, media, morena y oscura son tonos de piel",
        },
        ojos: { type: "string", enum: EYE_COLORS.map((x) => x.id), description: "Color de ojos" },
        antena: { type: "boolean", description: "La antena de Lumi (los gorros la tapan)" },
        cabello: { type: "string", enum: HAIRS.map((x) => x.id) },
        cabelloColor: { type: "string", enum: HAIR_COLORS.map((x) => x.id) },
        vello: { type: "string", enum: FACIALS.map((x) => x.id), description: "Barba o bigote" },
        prenda: { type: "string", enum: OUTFITS.map((x) => x.id) },
        prendaColor: { type: "string", enum: COLORS.map((x) => x.id) },
        lentes: { type: "string", enum: GLASSES.map((x) => x.id) },
        lentesColor: { type: "string", enum: FRAMES.map((x) => x.id), description: "Color del armazón" },
        accesorio: { type: "string", enum: ACCESSORIES.map((x) => x.id), description: "Accesorio de cabeza" },
        accesorioColor: { type: "string", enum: COLORS.map((x) => x.id) },
      },
    },
  },
];

export interface ToolContext {
  brain: Brain | null;
  meetings: Meeting[];
  sources: ChatSource[];
  actions: ChatAction[];
  origin: string | null;
}

const str = (v: unknown) => (typeof v === "string" && v.trim() ? v.trim() : null);

function addSource(ctx: ToolContext, path: string, title: string) {
  if (!ctx.sources.some((s) => s.path === path)) ctx.sources.push({ path, title });
}

async function createTask(ctx: ToolContext, input: Record<string, unknown>): Promise<string> {
  if (!ctx.brain) return "No hay vault configurado todavía.";
  const tags: Tag[] = [];
  const cliente = str(input.cliente);
  const proyecto = str(input.proyecto);
  if (cliente) tags.push({ kind: "cliente", name: cliente });
  if (proyecto) tags.push({ kind: "proyecto", name: proyecto });
  const fecha = str(input.fecha);
  const hora = str(input.hora);
  const draft: TaskDraft = {
    title: str(input.titulo) ?? "Pendiente",
    date: fecha && /^\d{4}-\d{2}-\d{2}$/.test(fecha) ? fecha : null,
    time: hora && /^\d{1,2}:\d{2}$/.test(hora) ? hora.padStart(5, "0") : null,
    tags,
    contact: str(input.persona),
  };
  const key = await ctx.brain.createTask(draft);
  const when = draft.date ? whenLabel(new Date(`${draft.date}T${draft.time ?? "09:00"}`).toISOString()) : "sin fecha";
  ctx.actions.push({ kind: "pendiente", label: draft.title, detail: when, taskKey: key, state: "hecho" });
  return `Pendiente creado: «${draft.title}» (${when}).`;
}

export async function executeTool(ctx: ToolContext, call: ToolCall): Promise<{ content: string; isError?: boolean }> {
  try {
    const input = call.input ?? {};
    switch (call.name) {
      case "buscar_en_vault": {
        if (!ctx.brain) return { content: "No hay vault configurado." };
        const hits = await ctx.brain.searcher.search(str(input.consulta) ?? "", { k: 8 });
        if (!hits.length) return { content: "Sin resultados." };
        for (const h of hits) addSource(ctx, h.path, h.title);
        return { content: hits.map((h) => `### ${h.title}${h.heading ? ` › ${h.heading}` : ""} (${h.path})\n${h.snippet}`).join("\n\n") };
      }
      case "leer_nota": {
        if (!ctx.brain) return { content: "No hay vault configurado." };
        const rel = ctx.brain.resolveNote(str(input.nota) ?? "");
        if (!rel) return { content: "No encontré esa nota.", isError: true };
        const note = await ctx.brain.readForAI(rel);
        if (!note) return { content: "Esa nota es privada o está excluida; no puedo leerla.", isError: true };
        addSource(ctx, rel, note.title);
        const text = note.text.length > 14_000 ? `${note.text.slice(0, 14_000)}\n…(recortada)` : note.text;
        return { content: `# ${note.title} (${rel})\n${text}` };
      }
      case "listar_pendientes": {
        if (!ctx.brain) return { content: "No hay vault configurado." };
        const now = new Date();
        const endToday = addDays(startOfDay(now), 1).getTime();
        const endWeek = addDays(startOfDay(now), 7).getTime();
        const periodo = str(input.periodo) ?? "todos";
        const etiqueta = str(input.etiqueta)?.toLowerCase();
        const list = ctx.brain
          .tasks()
          .filter((t) => !t.done && !t.private)
          .filter((t) => {
            const at = t.remindAt ? new Date(t.remindAt).getTime() : null;
            if (periodo === "hoy") return at !== null && at < endToday;
            if (periodo === "atrasados") return at !== null && at < now.getTime();
            if (periodo === "semana") return at !== null && at < endWeek;
            return true;
          })
          .filter((t) => !etiqueta || t.tags.some((g) => g.name.toLowerCase().includes(etiqueta)) || t.text.toLowerCase().includes(etiqueta))
          .slice(0, 60);
        return {
          content: list.length
            ? list.map((t) => `- ${t.text} — ${t.remindAt ? whenLabel(t.remindAt) : "sin fecha"}${t.tags.length ? ` [${t.tags.map((g) => g.name).join(", ")}]` : ""}`).join("\n")
            : "No hay pendientes con ese filtro.",
        };
      }
      case "proximas_reuniones": {
        const list = ctx.meetings.filter((m) => new Date(m.end) > new Date()).slice(0, 30);
        return {
          content: list.length
            ? list.map((m) => `- ${whenLabel(m.start)}: ${m.title}${m.attendees.length ? ` · ${m.attendees.slice(0, 6).join(", ")}` : ""}`).join("\n")
            : "No hay reuniones en los próximos 7 días (o el calendario no está conectado).",
        };
      }
      case "crear_pendiente":
      case "agendar_recordatorio":
        return { content: await createTask(ctx, input) };
      case "proponer_recuerdo": {
        const hecho = str(input.hecho);
        if (!hecho) return { content: "Falta el hecho.", isError: true };
        const p = proposeFact(ctx.brain, hecho, str(input.tema) ?? "General", ctx.origin);
        if (!p) return { content: "Ya lo sé o el aprendizaje está apagado; no hace falta guardarlo." };
        ctx.actions.push({ kind: "recuerdo", label: p.text, detail: p.topic, proposalId: p.id, state: "pendiente" });
        return { content: "Propuesta registrada; el usuario la confirmará." };
      }
      case "cambiar_apariencia": {
        const before = getSettings().avatar;
        const { next, changed } = applyAvatarPatch(before, input);
        if (!changed.length) return { content: "No hubo cambios válidos; tu apariencia sigue igual: " + describeAvatar(before) };
        updateSettings({ avatar: next });
        ctx.actions.push({ kind: "apariencia", label: "Me cambié el look", detail: describeAvatar(next), lookBefore: before, state: "hecho" });
        return { content: `Listo, ahora te ves así: ${describeAvatar(next)}.` };
      }
      default:
        return { content: `Herramienta desconocida: ${call.name}`, isError: true };
    }
  } catch (e) {
    return { content: `Error: ${errorText(e)}`, isError: true };
  }
}
