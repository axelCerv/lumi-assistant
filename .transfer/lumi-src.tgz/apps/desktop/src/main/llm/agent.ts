/** Conversación con la IA: contexto + herramientas + respuesta que se va escribiendo. */
import type { ChatAction, ChatMessage, ChatResponse, ChatSource, ContentBlock, LLMProvider, Meeting, Message } from "@lumi/shared";
import type { Brain } from "../vault/brain";
import { buildContext } from "../memory/context-builder";
import { getSettings } from "../settings";
import { requireProvider } from "./provider";
import { LUMI_TOOLS, executeTool, type ToolContext } from "./tools";
import { today } from "../vault/vault";

const MAX_ROUNDS = 6;

function systemPrompt(context: string): string {
  const learn = getSettings().learn;
  return `Eres Lumi, un asistente personal de escritorio: amable, cálido y práctico. Hablas en español de México, en tono cercano, con respuestas breves y accionables (usa listas cortas solo si ayudan).

Conoces el "cerebro" del usuario: su vault de Obsidian con reuniones, clientes, proyectos, personas, diario, pendientes y memoria. Ayudas a organizar el día, recordar lo acordado y sugerir qué hacer.

Reglas:
- Usa solo la información del contexto, de la conversación y de tus herramientas. Si no sabes algo, búscalo con buscar_en_vault o dilo con honestidad. No inventes reuniones, personas, fechas ni acuerdos.
- Cuando uses información de una nota, menciona su título entre corchetes dobles, por ejemplo [[Revisión trimestral Acme]].
- Si el usuario pide anotar o recordar algo, usa crear_pendiente o agendar_recordatorio. Fechas en formato AAAA-MM-DD; hoy es ${today()}.
${learn ? "- Si el usuario comparte un dato durable que valga la pena recordar y que no esté en la memoria, usa proponer_recuerdo (máximo uno por respuesta). Nunca propongas datos sensibles (salud, contraseñas, cuentas bancarias)." : "- El aprendizaje está apagado: no uses proponer_recuerdo."}
- Tú eres una esferita que flota en la pantalla y el usuario puede vestirte. Si te pide cambiar tu apariencia (ropa, cabello, lentes, accesorios, colores), usa cambiar_apariencia. Nunca cambies tu apariencia por tu cuenta. Puedes mencionar tu look con naturalidad, sin insistir.
- Después de usar una herramienta, responde al usuario de forma natural; no menciones nombres de herramientas.

# Contexto del usuario
${context}`;
}

function historyToMessages(history: ChatMessage[]): Message[] {
  const out: Message[] = [];
  for (const m of history.filter((x) => !x.error).slice(-14)) {
    const last = out[out.length - 1];
    if (last && last.role === m.role && typeof last.content === "string") last.content += `\n\n${m.content}`;
    else out.push({ role: m.role, content: m.content });
  }
  while (out.length && out[0].role !== "user") out.shift();
  return out;
}

export interface ChatResult {
  content: string;
  sources: ChatSource[];
  actions: ChatAction[];
}

export async function runChat(opts: {
  brain: Brain | null;
  meetings: Meeting[];
  history: ChatMessage[];
  userText: string;
  onDelta: (fullText: string) => void;
  provider?: LLMProvider;
}): Promise<ChatResult> {
  const provider = opts.provider ?? requireProvider();
  const ctx = await buildContext(opts.brain, opts.meetings, opts.userText);
  const toolCtx: ToolContext = {
    brain: opts.brain,
    meetings: opts.meetings,
    sources: [...ctx.sources],
    actions: [],
    origin: `[[${today()}]]`,
  };
  const messages: Message[] = [...historyToMessages(opts.history), { role: "user", content: opts.userText }];
  // si el historial terminaba en "user", se juntan los turnos
  const merged: Message[] = [];
  for (const m of messages) {
    const last = merged[merged.length - 1];
    if (last && last.role === m.role && typeof last.content === "string" && typeof m.content === "string") last.content += `\n\n${m.content}`;
    else merged.push(m);
  }

  const system = systemPrompt(ctx.text);
  let full = "";
  for (let round = 0; round < MAX_ROUNDS; round++) {
    let response: ChatResponse | null = null;
    let roundText = "";
    for await (const chunk of provider.stream({ system, messages: merged, tools: LUMI_TOOLS, profile: "inteligente", maxTokens: 1800 })) {
      if (chunk.type === "text" && chunk.text) {
        roundText += chunk.text;
        opts.onDelta(full + roundText);
      } else if (chunk.type === "done") response = chunk.response ?? null;
    }
    if (!response) break;
    full += roundText;
    if (!response.toolCalls.length) break;

    const assistantBlocks: ContentBlock[] = [];
    if (response.text) assistantBlocks.push({ type: "text", text: response.text });
    for (const tc of response.toolCalls) assistantBlocks.push({ type: "tool_call", id: tc.id, name: tc.name, input: tc.input });
    merged.push({ role: "assistant", content: assistantBlocks, raw: response.raw });

    const results: ContentBlock[] = [];
    for (const tc of response.toolCalls) {
      const r = await executeTool(toolCtx, tc);
      results.push({ type: "tool_result", id: tc.id, name: tc.name, content: r.content, isError: r.isError });
    }
    merged.push({ role: "user", content: results });
    if (full && !full.endsWith("\n")) full += "\n\n";
  }

  // Solo se muestran como fuentes las notas que la respuesta usó o las que buscó/leyó
  const cited = toolCtx.sources.filter((s) => full.includes(s.title) || !ctx.sources.some((c) => c.path === s.path));
  return { content: full.trim() || "Listo.", sources: cited.slice(0, 8), actions: toolCtx.actions };
}
