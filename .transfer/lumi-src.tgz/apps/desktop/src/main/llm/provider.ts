/** Elige el proveedor de IA según la configuración y las claves guardadas. */
import type { LLMProvider, ProviderId } from "@lumi/shared";
import { LLMError } from "@lumi/shared";
import { getSettings } from "../settings";
import { getSecret } from "../secrets";
import { ClaudeProvider } from "./claude";
import { GeminiProvider } from "./gemini";

export function providerFor(id: ProviderId): LLMProvider {
  const s = getSettings();
  const key = getSecret(id);
  if (!key) throw new LLMError(id === "claude" ? "Falta tu clave de Claude (Ajustes → Inteligencia)." : "Falta tu clave de Gemini (Ajustes → Inteligencia).");
  const models = s.ai.models[id];
  return id === "claude" ? new ClaudeProvider(key, models) : new GeminiProvider(key, models);
}

/** El proveedor activo, o null si la IA está apagada o sin clave. */
export function activeProvider(): LLMProvider | null {
  const s = getSettings();
  if (!s.ai.enabled) return null;
  if (s.ai.provider === "gemini" && !s.ai.geminiPrivacyAccepted) return null;
  try {
    return providerFor(s.ai.provider);
  } catch {
    return null;
  }
}

export function requireProvider(): LLMProvider {
  const s = getSettings();
  if (!s.ai.enabled) throw new LLMError("La IA está apagada en Ajustes.");
  if (s.ai.provider === "gemini" && !s.ai.geminiPrivacyAccepted) throw new LLMError("Acepta el aviso de privacidad de Gemini en Ajustes.");
  return providerFor(s.ai.provider);
}

/** Extrae el primer objeto JSON de un texto (por si el modelo agrega algo alrededor). */
export function parseJsonLoose<T>(text: string): T | null {
  const clean = text.replace(/```(?:json)?/g, "").trim();
  try {
    return JSON.parse(clean) as T;
  } catch {
    const m = clean.match(/\{[\s\S]*\}/);
    if (!m) return null;
    try {
      return JSON.parse(m[0]) as T;
    } catch {
      return null;
    }
  }
}
