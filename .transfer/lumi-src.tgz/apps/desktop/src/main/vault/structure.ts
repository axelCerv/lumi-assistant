/** Estructura y plantillas iniciales del vault (templates/vault del repositorio). */
import { promises as fs } from "node:fs";
import path from "node:path";
import { Vault, today } from "./vault";
import { exists } from "../util";

export const FOLDERS = {
  inbox: "00-Inbox",
  diario: "01-Diario",
  reuniones: "02-Reuniones",
  pendientes: "03-Pendientes",
  proyectos: "04-Proyectos",
  clientes: "05-Clientes",
  personas: "06-Personas",
  rutinas: "07-Rutinas",
  conocimiento: "08-Conocimiento",
  lumi: "90-Lumi",
  memoria: "90-Lumi/memoria",
  resumenes: "90-Lumi/resumenes",
  plantillas: "99-Plantillas",
} as const;

export const FILES = {
  perfil: "90-Lumi/perfil.md",
  preferencias: "90-Lumi/preferencias.md",
  pendientes: "03-Pendientes/Pendientes.md",
  ignore: ".lumiignore",
};

// Las plantillas se incluyen en el build (Vite las lee como texto).
const TEMPLATES = import.meta.glob("../../../../../templates/vault/**/*", {
  query: "?raw",
  import: "default",
  eager: true,
}) as Record<string, string>;

function templateFiles(): { rel: string; content: string }[] {
  return Object.entries(TEMPLATES).map(([key, content]) => {
    let rel = key.split("templates/vault/")[1];
    if (rel === "lumiignore.txt") rel = FILES.ignore;
    return { rel, content };
  });
}

export function templateFor(name: "Reunión" | "Persona" | "Cliente" | "Proyecto" | "Nota diaria" | "Rutina"): string {
  return templateFiles().find((t) => t.rel === `${FOLDERS.plantillas}/${name}.md`)?.content ?? "";
}

/** Rellena los marcadores de plantilla de Obsidian ({{title}}, {{date:…}}). */
export function fillTemplate(tpl: string, values: { title?: string; date?: string } = {}): string {
  return tpl
    .replace(/\{\{title\}\}/g, values.title ?? "")
    .replace(/\{\{date(?::[^}]*)?\}\}/g, values.date ?? today());
}

/** ¿Parece un vault de Obsidian (o al menos una carpeta con notas)? */
export async function looksLikeVault(root: string): Promise<boolean> {
  return (await exists(path.join(root, ".obsidian"))) || (await exists(path.join(root, FOLDERS.lumi)));
}

/**
 * Crea las carpetas de Lumi y copia las plantillas que falten.
 * Nunca reemplaza un archivo existente: sirve igual para un vault nuevo o uno que ya usas.
 */
export async function installStructure(root: string, placeholders: Record<string, string> = {}): Promise<void> {
  await fs.mkdir(root, { recursive: true });
  for (const f of Object.values(FOLDERS)) await fs.mkdir(path.join(root, f), { recursive: true });
  const vault = new Vault(root);
  for (const t of templateFiles()) {
    if (await vault.exists(t.rel)) continue;
    let content = t.content;
    // Los archivos de 90-Lumi usan marcadores {{clave}} propios; las plantillas se dejan intactas
    if (!t.rel.startsWith(FOLDERS.plantillas)) {
      content = content.replace(/\{\{(\w+)\}\}/g, (_, k: string) => placeholders[k] ?? "");
    }
    await fs.mkdir(path.dirname(vault.abs(t.rel)), { recursive: true });
    await fs.writeFile(vault.abs(t.rel), content, "utf8");
  }
}
