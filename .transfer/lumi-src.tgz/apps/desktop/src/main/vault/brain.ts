/**
 * El "cerebro" de Lumi: el vault + su índice. Expone operaciones de alto nivel
 * (pendientes, entidades, rutinas, memoria, búsqueda) respetando las reglas del vault.
 */
import path from "node:path";
import fs from "node:fs";
import { createHash } from "node:crypto";
import { watch, type FSWatcher } from "chokidar";
import {
  formatTaskLine,
  parseTaskLine,
  slugify,
  safeFileName,
  toggleTaskLine,
  DAY_NAMES,
  type Entity,
  type MemoryFact,
  type Routine,
  type SummaryInfo,
  type Tag,
  type Task,
  type TaskDraft,
} from "@lumi/shared";
import { Vault, VaultError, today, type Frontmatter } from "./vault";
import { IgnoreRules } from "./ignore";
import { FILES, FOLDERS, fillTemplate, templateFor } from "./structure";
import { openIndex, type IndexDb } from "../index/db";
import { Indexer } from "../index/indexer";
import { Searcher } from "../index/search";
import { BrainEmbedder, EmbeddingQueue } from "../index/embeddings";
import { debounce, errorText, log } from "../util";

interface TaskRow {
  key: string;
  path: string;
  line: number;
  raw: string;
  text: string;
  done: number;
  due: string | null;
  time: string | null;
  done_date: string | null;
  tags: string;
  links: string;
  private: number;
  lumi: number;
}

const DAY_KEYS = DAY_NAMES.map((d) => d.normalize("NFD").replace(/[̀-ͯ]/g, ""));

export function dayIndex(name: string): number {
  const n = name.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").trim();
  const i = DAY_KEYS.indexOf(n);
  if (i >= 0) return i;
  const short: Record<string, number> = { dom: 0, lun: 1, mar: 2, mie: 3, jue: 4, vie: 5, sab: 6 };
  return short[n.slice(0, 3)] ?? -1;
}

function hhmm(d: Date): string {
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

export interface BrainStatus {
  indexing: boolean;
  progress: number;
}

export class Brain {
  readonly vault: Vault;
  readonly ignore: IgnoreRules;
  readonly idx: IndexDb;
  readonly indexer: Indexer;
  readonly searcher: Searcher;
  readonly queue: EmbeddingQueue;
  status: BrainStatus = { indexing: false, progress: 0 };
  private watcher: FSWatcher | null = null;
  private defaultTime = "09:00";

  constructor(
    root: string,
    userData: string,
    readonly embedder: BrainEmbedder,
    private onChange: () => void,
  ) {
    this.vault = new Vault(root);
    this.ignore = new IgnoreRules(root);
    const id = createHash("sha1").update(root).digest("hex").slice(0, 10);
    this.idx = openIndex(path.join(userData, `indice-${id}.sqlite`));
    this.indexer = new Indexer(this.vault, this.ignore, this.idx);
    this.searcher = new Searcher(this.idx, embedder);
    this.queue = new EmbeddingQueue(this.idx, embedder, debounce(() => this.onChange(), 1000));
  }

  setDefaultReminderTime(t: string): void {
    if (/^\d{1,2}:\d{2}$/.test(t)) this.defaultTime = t.padStart(5, "0");
  }

  async start(): Promise<void> {
    await this.reindex();
    this.watch();
  }

  async reindex(): Promise<void> {
    this.status = { indexing: true, progress: 0 };
    this.onChange();
    try {
      await this.indexer.fullScan((done, total) => {
        this.status = { indexing: true, progress: total ? done / total : 1 };
        this.onChange();
      });
    } finally {
      this.status = { indexing: false, progress: 1 };
      this.onChange();
      this.queue.kick();
    }
  }

  private watch(): void {
    const changed = debounce(() => {
      this.onChange();
      this.queue.kick();
    }, 400);
    this.watcher = watch(this.vault.root, {
      ignoreInitial: true,
      awaitWriteFinish: { stabilityThreshold: 350, pollInterval: 100 },
      ignored: (p: string) => {
        const rel = this.vault.rel(p);
        if (!rel || rel === ".lumiignore") return false;
        if (rel.split("/").some((seg) => seg.startsWith(".") && seg !== ".lumiignore")) return true;
        return this.ignore.isIgnored(rel);
      },
    });
    const onFile = async (p: string, removed: boolean) => {
      const rel = this.vault.rel(p);
      if (rel === ".lumiignore") {
        await this.reindex();
        return;
      }
      if (!rel.endsWith(".md")) return;
      try {
        if (removed) this.indexer.remove(rel);
        else await this.indexer.indexFile(rel);
        changed();
      } catch (e) {
        log.warn("watcher:", errorText(e));
      }
    };
    this.watcher.on("add", (p) => onFile(p, false));
    this.watcher.on("change", (p) => onFile(p, false));
    this.watcher.on("unlink", (p) => onFile(p, true));
  }

  async close(): Promise<void> {
    await this.watcher?.close();
    this.idx.db.close();
  }

  /** Reindexa un archivo de inmediato (después de que Lumi lo escribe). */
  async touch(rel: string): Promise<void> {
    await this.indexer.indexFile(rel);
    this.onChange();
    this.queue.kick();
  }

  /* ------------------------------ Entidades ------------------------------ */

  entities(): Entity[] {
    const rows = this.idx.db
      .prepare("SELECT path, type FROM notes WHERE type IN ('cliente','proyecto','persona') ORDER BY path")
      .all() as { path: string; type: Entity["kind"] }[];
    return rows.map((r) => {
      const name = r.path.split("/").pop()!.replace(/\.md$/, "");
      return { name, kind: r.type, path: r.path, slug: slugify(name) };
    });
  }

  tagToEntity(tag: string, ents = this.entities()): Tag | null {
    const m = /^(cliente|proyecto)\/(.+)$/.exec(tag);
    if (!m) return null;
    const kind = m[1] as Tag["kind"];
    const e = ents.find((x) => x.kind === kind && x.slug === m[2]);
    const name = e?.name ?? m[2].replace(/-/g, " ").replace(/^\w/, (c) => c.toUpperCase());
    return { kind, name };
  }

  /** Crea la nota de un cliente/proyecto/persona si no existe. Devuelve su nombre. */
  async ensureEntity(kind: Entity["kind"], name: string): Promise<string> {
    const existing = this.entities().find((e) => e.kind === kind && (e.slug === slugify(name) || e.name.toLowerCase() === name.toLowerCase()));
    if (existing) return existing.name;
    const folder = kind === "cliente" ? FOLDERS.clientes : kind === "proyecto" ? FOLDERS.proyectos : FOLDERS.personas;
    const fileName = safeFileName(name);
    const rel = `${folder}/${fileName}.md`;
    const tpl = fillTemplate(templateFor(kind === "cliente" ? "Cliente" : kind === "proyecto" ? "Proyecto" : "Persona"), { title: fileName });
    if (!(await this.vault.exists(rel))) {
      // Las notas de entidades son tuyas: Lumi solo las crea con la plantilla
      await this.vault.createIfMissing(rel, {}, tpl);
      await this.touch(rel);
    }
    return fileName;
  }

  /* ------------------------------ Pendientes ----------------------------- */

  private rowToTask(r: TaskRow, ents: Entity[]): Task {
    const tagList = JSON.parse(r.tags || "[]") as string[];
    const tags: Tag[] = [];
    const otherTags: string[] = [];
    for (const t of tagList) {
      const e = this.tagToEntity(t, ents);
      if (e) tags.push(e);
      else otherTags.push(t);
    }
    let remindAt: string | null = null;
    if (r.due) {
      const [y, mo, d] = r.due.split("-").map(Number);
      const [h, mi] = (r.time ?? this.defaultTime).split(":").map(Number);
      remindAt = new Date(y, mo - 1, d, h, mi).toISOString();
    }
    // "Mandar factura · Acme" → "Mandar factura" cuando Acme ya se muestra como etiqueta
    let text = r.text;
    for (const t of tags) text = text.replace(new RegExp(`\\s·\\s${t.name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?=\\s·|$)`), "");
    return {
      key: r.key,
      path: r.path,
      line: r.line,
      raw: r.raw,
      text: text.trim() || r.text,
      done: !!r.done,
      due: r.due,
      time: r.time,
      remindAt,
      doneDate: r.done_date,
      tags,
      otherTags,
      links: JSON.parse(r.links || "[]"),
      private: !!r.private,
      lumiFile: !!r.lumi,
    };
  }

  tasks(opts: { includeDone?: boolean } = {}): Task[] {
    const ents = this.entities();
    const rows = this.idx.db
      .prepare(
        `SELECT t.* FROM tasks t JOIN notes n ON n.path = t.path
         WHERE n.type NOT IN ('plantilla') ${opts.includeDone ? "" : "AND (t.done = 0 OR t.done_date >= date('now','-14 day'))"}`,
      )
      .all() as TaskRow[];
    return rows.map((r) => this.rowToTask(r, ents));
  }

  task(key: string): Task | null {
    const r = this.idx.db.prepare("SELECT * FROM tasks WHERE key = ?").get(key) as TaskRow | undefined;
    return r ? this.rowToTask(r, this.entities()) : null;
  }

  async appendInbox(text: string): Promise<void> {
    const day = today();
    const rel = `${FOLDERS.inbox}/${day}.md`;
    await this.vault.appendLumi(rel, `- ${hhmm(new Date())} · ${text.replace(/\n+/g, " ")}`, {
      fm: { type: "inbox", date: day },
      body: `# Inbox · ${day}\n\nNotas rápidas tal como las escribiste.`,
    });
    await this.touch(rel);
  }

  async createTask(draft: TaskDraft): Promise<string> {
    const tags: Tag[] = [];
    for (const t of draft.tags) tags.push({ kind: t.kind, name: await this.ensureEntity(t.kind, t.name) });
    const line = formatTaskLine({ ...draft, tags });
    await this.vault.appendLumi(FILES.pendientes, line, {
      fm: { type: "pendientes" },
      body: "# Pendientes\n\nPendientes que creaste con Lumi. Puedes marcarlos aquí, desde Lumi o desde el plugin Tasks.",
    });
    await this.touch(FILES.pendientes);
    const parsed = parseTaskLine(line)!;
    const row = this.idx.db
      .prepare("SELECT key FROM tasks WHERE path = ? AND text = ? ORDER BY line DESC LIMIT 1")
      .get(FILES.pendientes, parsed.text) as { key: string } | undefined;
    return row?.key ?? "";
  }

  /** Cambia un pendiente existente (a petición tuya). Conserva su estado. */
  async updateTask(key: string, draft: TaskDraft): Promise<string> {
    const t = this.task(key);
    if (!t) throw new VaultError("No encontré ese pendiente; quizá cambió en Obsidian.");
    const tags: Tag[] = [];
    for (const g of draft.tags) tags.push({ kind: g.kind, name: await this.ensureEntity(g.kind, g.name) });
    const indent = /^(\s*)/.exec(t.raw)?.[1] ?? "";
    let line = indent + formatTaskLine({ ...draft, tags });
    if (t.done) line = toggleTaskLine(line, t.doneDate ?? today());
    // Conserva etiquetas que no son de cliente/proyecto
    if (t.otherTags.length) line += ` ${t.otherTags.map((x) => `#${x}`).join(" ")}`;
    await this.vault.replaceLine(t.path, t.line, t.raw, line);
    await this.touch(t.path);
    const parsed = parseTaskLine(line)!;
    const row = this.idx.db.prepare("SELECT key FROM tasks WHERE path = ? AND text = ? LIMIT 1").get(t.path, parsed.text) as
      | { key: string }
      | undefined;
    return row?.key ?? key;
  }

  async toggleTask(key: string): Promise<Task | null> {
    const t = this.task(key);
    if (!t) throw new VaultError("No encontré ese pendiente; quizá cambió en Obsidian.");
    await this.vault.replaceLine(t.path, t.line, t.raw, toggleTaskLine(t.raw, today()));
    await this.touch(t.path);
    return t;
  }

  async deleteTask(key: string): Promise<void> {
    const t = this.task(key);
    if (!t) return;
    if (!t.lumiFile) throw new VaultError("Ese pendiente vive en una nota tuya: bórralo desde Obsidian.");
    await this.vault.replaceLine(t.path, t.line, t.raw, null);
    await this.touch(t.path);
  }

  taskDraft(key: string): TaskDraft | null {
    const t = this.task(key);
    if (!t) return null;
    const contact = t.links.find((l) => !t.tags.some((g) => g.name === l)) ?? null;
    return { title: t.text, date: t.due, time: t.time, tags: t.tags, contact };
  }

  /* ------------------------------- Rutinas ------------------------------- */

  routines(): Routine[] {
    const rows = this.idx.db.prepare("SELECT path, title, fm FROM notes WHERE type = 'rutina'").all() as {
      path: string;
      title: string;
      fm: string;
    }[];
    return rows.map((r) => {
      const fm = JSON.parse(r.fm) as Frontmatter;
      const dias = Array.isArray(fm.dias) ? fm.dias : typeof fm.dias === "string" ? fm.dias.split(/[,\s]+/) : ["lunes", "martes", "miércoles", "jueves", "viernes"];
      const days = dias.map((d) => (typeof d === "number" ? d : dayIndex(String(d)))).filter((d) => d >= 0 && d <= 6);
      const hora = typeof fm.hora === "string" ? fm.hora : typeof fm.hora === "number" ? `${Math.floor(fm.hora / 60)}:${fm.hora % 60}` : "09:00";
      return {
        path: r.path,
        title: r.title,
        days,
        time: hora.padStart(5, "0"),
        active: fm.activa !== false,
        lumiFile: fm.source === "lumi",
      };
    });
  }

  async createRoutine(r: { title: string; days: number[]; time: string }): Promise<string> {
    const rel = await this.vault.createNew(
      `${FOLDERS.rutinas}/${safeFileName(r.title)}.md`,
      { type: "rutina", dias: [...r.days].sort().map((d) => DAY_NAMES[d]), hora: r.time, activa: true, source: "lumi" },
      `# ${r.title}\n\nRutina creada con Lumi.\n`,
    );
    await this.touch(rel);
    return rel;
  }

  async setRoutineActive(rel: string, active: boolean): Promise<void> {
    await this.vault.setFrontmatter(rel, { activa: active }, { userRequested: true });
    await this.touch(rel);
  }

  async deleteRoutine(rel: string): Promise<void> {
    await this.vault.deleteLumiFile(rel);
    this.indexer.remove(rel);
    this.onChange();
  }

  /* ------------------------------- Memoria ------------------------------- */

  facts(): MemoryFact[] {
    const rows = this.idx.db.prepare("SELECT path FROM notes WHERE path LIKE ?").all(`${FOLDERS.memoria}/%`) as { path: string }[];
    return rows.flatMap((r) => this.factsIn(r.path));
  }

  private factsCache = new Map<string, { mtime: number; facts: MemoryFact[] }>();

  private factsIn(rel: string): MemoryFact[] {
    try {
      const abs = this.vault.abs(rel);
      const mtime = fs.statSync(abs).mtimeMs;
      const c = this.factsCache.get(rel);
      if (c && c.mtime === mtime) return c.facts;
      const lines = fs.readFileSync(abs, "utf8").split(/\r?\n/);
      const topic = rel.split("/").pop()!.replace(/\.md$/, "");
      const facts: MemoryFact[] = [];
      lines.forEach((line, i) => {
        const m = /^- (\d{4}-\d{2}-\d{2}) · (.+?)(?: · \(origen: (.+)\))?\s*$/.exec(line);
        if (m) facts.push({ topic, date: m[1], text: m[2], origin: m[3] ?? null, path: rel, line: i });
      });
      this.factsCache.set(rel, { mtime, facts });
      return facts;
    } catch {
      return [];
    }
  }

  async addFact(text: string, topic: string, origin: string | null): Promise<void> {
    const name = safeFileName(topic || "General");
    const rel = `${FOLDERS.memoria}/${name}.md`;
    const line = `- ${today()} · ${text.replace(/\n+/g, " ").trim()}${origin ? ` · (origen: ${origin})` : ""}`;
    await this.vault.appendLumi(rel, line, {
      fm: { type: "memoria", tema: name },
      body: `# Memoria · ${name}\n\nHechos que confirmaste para que Lumi los recuerde.\n`,
    });
    await this.touch(rel);
  }

  async deleteFact(rel: string, lineNo: number): Promise<void> {
    const f = this.factsIn(rel).find((x) => x.line === lineNo);
    if (!f) return;
    const note = await this.vault.read(rel);
    if (!note || !this.vault.isLumiOwned(note.fm)) throw new VaultError("Ese archivo de memoria es tuyo: edítalo en Obsidian.");
    const raw = note.raw.split(/\r?\n/)[lineNo];
    await this.vault.replaceLine(rel, lineNo, raw, null);
    await this.touch(rel);
  }

  summaries(): SummaryInfo[] {
    const rows = this.idx.db
      .prepare("SELECT path, title, fm, date FROM notes WHERE path LIKE ? ORDER BY path DESC")
      .all(`${FOLDERS.resumenes}/%`) as { path: string; title: string; fm: string; date: string | null }[];
    return rows.map((r) => {
      const fm = JSON.parse(r.fm) as Frontmatter;
      return {
        path: r.path,
        title: r.title,
        kind: fm.periodo === "mensual" ? "mensual" : "semanal",
        date: (typeof fm.date === "string" ? fm.date : r.date) ?? "",
      };
    });
  }

  /* ------------------------------- Lectura ------------------------------- */

  /** Lee una nota para la IA. Respeta .lumiignore y `lumi: privado`. */
  async readForAI(rel: string): Promise<{ title: string; text: string } | null> {
    if (this.ignore.isIgnored(rel)) return null;
    const note = await this.vault.read(rel);
    if (!note || note.fm.lumi === "privado" || note.fm.lumi === "private") return null;
    const row = this.idx.db.prepare("SELECT title FROM notes WHERE path = ?").get(rel) as { title: string } | undefined;
    return { title: row?.title ?? rel, text: note.body };
  }

  /** Busca una nota por nombre o ruta aproximada. */
  resolveNote(nameOrPath: string): string | null {
    const q = nameOrPath.replace(/^\[\[|\]\]$/g, "").replace(/\.md$/, "").trim();
    const direct = this.idx.db.prepare("SELECT path FROM notes WHERE path = ? OR path = ?").get(q, `${q}.md`) as { path: string } | undefined;
    if (direct) return direct.path;
    const byName = this.idx.db
      .prepare("SELECT path FROM notes WHERE lower(path) LIKE ? OR lower(title) = ? ORDER BY length(path) LIMIT 1")
      .get(`%/${q.toLowerCase()}.md`, q.toLowerCase()) as { path: string } | undefined;
    return byName?.path ?? null;
  }

  /** Notas con fecha dentro de un rango (para resúmenes). */
  notesBetween(from: string, to: string, types?: string[]): { path: string; title: string; type: string; date: string }[] {
    const rows = this.idx.db
      .prepare("SELECT path, title, type, date FROM notes WHERE date >= ? AND date <= ? AND private = 0 ORDER BY date")
      .all(from, to) as { path: string; title: string; type: string; date: string }[];
    return types ? rows.filter((r) => types.includes(r.type)) : rows;
  }

  noteMeta(rel: string): { title: string; type: string; fm: Frontmatter } | null {
    const r = this.idx.db.prepare("SELECT title, type, fm FROM notes WHERE path = ?").get(rel) as
      | { title: string; type: string; fm: string }
      | undefined;
    return r ? { title: r.title, type: r.type, fm: JSON.parse(r.fm) } : null;
  }

  findByFrontmatter(key: string, value: string): string | null {
    const r = this.idx.db
      .prepare("SELECT path FROM notes WHERE json_extract(fm, ?) = ? LIMIT 1")
      .get(`$.${key}`, value) as { path: string } | undefined;
    return r?.path ?? null;
  }
}
