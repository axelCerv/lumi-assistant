/**
 * El reloj de Lumi (proceso principal): decide qué avisar y cuándo.
 * Orden: saludo del día → reuniones → recordatorios → rutinas → sugerencias →
 * resúmenes periódicos. Un aviso a la vez.
 */
import { Notification, shell } from "electron";
import { addDays, dayKey, fmtTime, greeting, relative, startOfDay, type BubbleAction, type BubblePayload } from "@lumi/shared";
import { getBrain, scheduleSnapshot } from "../core";
import { getSettings, updateSettings } from "../settings";
import { getState, mutateState } from "../state";
import { meetings, refreshCalendars } from "../calendar";
import { syncGranola, openGranolaApp } from "../granola/sync";
import { suggestRoutines, suggestionText } from "../memory/habits";
import { generateSummary, periodFor } from "../memory/summaries";
import { activeProvider } from "../llm/provider";
import { bubbleBusy, getBubble, hideBubble, showBubble, showPanel } from "../windows";
import { errorText, log } from "../util";
import { obsidianUrl } from "../memory/context-builder";

const TICK = 20_000;
let busy = false;
let welcomed = false;
let summarizing = false;

function lowerFirst(s: string) {
  return s ? s[0].toLowerCase() + s.slice(1) : s;
}

function notify(title: string, body: string) {
  if (!getSettings().systemNotifications || !Notification.isSupported()) return;
  const n = new Notification({ title, body, silent: false });
  n.on("click", () => showPanel());
  n.show();
}

function show(p: BubblePayload, systemTitle?: string) {
  showBubble(p);
  if (systemTitle) notify(systemTitle, p.text);
}

export function startScheduler(): void {
  setTimeout(tick, 4000);
  setInterval(tick, TICK);
  void refreshCalendars();
  setInterval(() => void refreshCalendars(), 10 * 60_000);
  setTimeout(() => void syncGranola(getBrain()).catch(() => {}), 15_000);
  setInterval(() => void syncGranola(getBrain()).catch(() => {}), 15 * 60_000);
}

export async function tick(): Promise<void> {
  if (busy) return;
  busy = true;
  try {
    const s = getSettings();
    const brain = getBrain();
    const now = new Date();
    const today = dayKey(now);

    if (!s.onboarded) {
      if (!welcomed && !bubbleBusy()) {
        welcomed = true;
        showPanel();
      }
      return;
    }

    maybeSummaries(now);
    if (bubbleBusy()) return;
    const st = getState();
    const name = s.userName.trim();

    // 1) Saludo del día
    if (s.lastGreeting !== today && now.getHours() >= 6) {
      updateSettings({ lastGreeting: today });
      const end = addDays(startOfDay(now), 1);
      const pending = brain?.tasks().filter((t) => !t.done && t.remindAt && new Date(t.remindAt) < end).length ?? 0;
      const todays = meetings().filter((m) => !m.allDay && new Date(m.start) >= now && new Date(m.start) < end);
      const parts = [pending === 0 ? "no tienes pendientes para hoy" : pending === 1 ? "tienes 1 pendiente hoy" : `tienes ${pending} pendientes hoy`];
      if (todays.length) parts.push(`${todays.length === 1 ? "1 reunión" : `${todays.length} reuniones`}, la primera a las ${fmtTime(new Date(todays[0].start))}`);
      show({ kind: "hola", text: `¡${greeting(now)}${name ? `, ${name}` : ""}! Hoy ${parts.join(" y ")}.`, time: fmtTime(now) });
      return;
    }

    // 2) Reuniones por empezar
    for (const m of meetings()) {
      if (m.allDay || st.alertedMeetings[m.id]) continue;
      const start = new Date(m.start).getTime();
      if (now.getTime() >= start - s.meetingLeadMin * 60_000 && now.getTime() < start + 2 * 60_000) {
        mutateState((x) => (x.alertedMeetings[m.id] = now.toISOString()));
        const granola = s.granola.mode !== "none" && s.askGranolaBeforeMeeting;
        show(
          {
            kind: "reunion",
            text: `Tu reunión «${m.title}» empieza ${relative(new Date(start), now)}, a las ${fmtTime(new Date(start))}.${granola ? " ¿Abro Granola para grabarla?" : ""}`,
            time: relative(new Date(start), now),
            meetingId: m.id,
            link: m.link,
            granola,
          },
          "Reunión en camino",
        );
        return;
      }
    }

    // 3) Recordatorios
    if (brain) {
      const due = brain
        .tasks()
        .filter((t) => {
          if (t.done || !t.remindAt) return false;
          const snoozed = st.snoozed[t.key];
          if (snoozed) return new Date(snoozed) <= now;
          return !st.notified[t.key] && new Date(t.remindAt) <= now && now.getTime() - new Date(t.remindAt).getTime() < 3 * 86400000;
        })
        .sort((a, b) => (a.remindAt ?? "").localeCompare(b.remindAt ?? ""));
      if (due.length) {
        const t = due[0];
        mutateState((x) => {
          x.notified[t.key] = now.toISOString();
          delete x.snoozed[t.key];
        });
        const at = new Date(t.remindAt!);
        const late = now.getTime() - at.getTime() > 30 * 60_000;
        const lead = name ? `${name}, ` : "";
        show(
          {
            kind: "recordatorio",
            text: late ? `${lead}esto quedó pendiente desde las ${fmtTime(at)}: ${lowerFirst(t.text)}. ¿Lo hacemos ahora?` : `${lead}te recuerdo: ${lowerFirst(t.text)}. ¿Lo hacemos ahora?`,
            time: fmtTime(at),
            tags: t.tags,
            taskKey: t.key,
            notePath: t.path,
          },
          "Lumi te recuerda",
        );
        return;
      }

      // 4) Rutinas
      for (const r of brain.routines()) {
        const sk = `rutina:${r.path}`;
        if (st.snoozed[sk]) {
          if (new Date(st.snoozed[sk]) > now) continue;
          mutateState((x) => delete x.snoozed[sk]);
          show({ kind: "rutina", text: `Es hora de: ${lowerFirst(r.title)}.`, time: r.time, routinePath: r.path }, "Rutina");
          return;
        }
        if (!r.active || !r.days.includes(now.getDay()) || st.routinesFired[r.path] === today) continue;
        const [h, mi] = r.time.split(":").map(Number);
        const at = new Date(now);
        at.setHours(h, mi, 0, 0);
        const diff = now.getTime() - at.getTime();
        if (diff >= 0 && diff < 90 * 60_000) {
          mutateState((x) => (x.routinesFired[r.path] = today));
          show({ kind: "rutina", text: `Es hora de: ${lowerFirst(r.title)}.`, time: r.time, routinePath: r.path }, "Rutina");
          return;
        }
      }
    }

    // 5) Una vez al día: ¿algo que haces seguido?
    if (s.lastSuggestionCheck !== today && now.getHours() >= 10) {
      updateSettings({ lastSuggestionCheck: today });
      const sug = suggestRoutines(brain, now)[0];
      if (sug) show({ kind: "sugerencia", text: suggestionText(sug), time: "Hábito detectado", suggestion: sug });
    }
  } catch (e) {
    log.error("tick:", errorText(e));
  } finally {
    busy = false;
  }
}

/** Resumen semanal (lunes) y mensual (día 1), en segundo plano. */
function maybeSummaries(now: Date): void {
  const brain = getBrain();
  if (summarizing || !brain || !activeProvider() || now.getHours() < 9) return;
  const s = getSettings();
  const weekly = periodFor("semanal", now);
  const monthly = periodFor("mensual", now);
  let kind: "semanal" | "mensual" | null = null;
  if (now.getDate() <= 3 && s.lastMonthlySummary !== monthly.rel) kind = "mensual";
  else if (s.lastWeeklySummary !== weekly.rel && now.getDay() >= 1) kind = "semanal";
  if (!kind) return;
  summarizing = true;
  const rel = kind === "semanal" ? weekly.rel : monthly.rel;
  generateSummary(brain, kind, now)
    .then((path) => {
      updateSettings(kind === "semanal" ? { lastWeeklySummary: rel } : { lastMonthlySummary: rel });
      if (!bubbleBusy()) show({ kind: "resumen", text: `Te dejé tu resumen ${kind} en el vault.`, time: kind === "semanal" ? "Semana" : "Mes", notePath: path });
    })
    .catch((e) => {
      log.warn("resumen:", errorText(e));
      // no reintenta hasta el próximo periodo si falla por falta de material
      updateSettings(kind === "semanal" ? { lastWeeklySummary: rel } : { lastMonthlySummary: rel });
    })
    .finally(() => (summarizing = false));
}

/** Botones de la burbuja. */
export async function bubbleAction(action: BubbleAction, minutes?: number): Promise<void> {
  const p = getBubble();
  const brain = getBrain();
  hideBubble();
  if (!p) return;
  try {
    switch (action) {
      case "done":
        if (p.taskKey && brain) {
          const t = await brain.toggleTask(p.taskKey);
          if (t) mutateState((x) => x.completions.push({ text: t.text, at: new Date().toISOString() }));
        } else if (p.routinePath) {
          const r = brain?.routines().find((x) => x.path === p.routinePath);
          if (r) mutateState((x) => x.completions.push({ text: r.title, at: new Date().toISOString() }));
        }
        break;
      case "snooze":
        if (p.taskKey) {
          const until = new Date(Date.now() + (minutes ?? 30) * 60_000).toISOString();
          mutateState((x) => (x.snoozed[p.taskKey!] = until));
        } else if (p.routinePath) {
          const until = new Date(Date.now() + (minutes ?? 15) * 60_000).toISOString();
          mutateState((x) => (x.snoozed[`rutina:${p.routinePath}`] = until));
        }
        break;
      case "open-link":
        if (p.link) await shell.openExternal(p.link);
        break;
      case "open-granola":
        openGranolaApp();
        break;
      case "open-panel":
        showPanel();
        break;
      case "open-note":
        if (p.notePath && brain) await shell.openExternal(obsidianUrl(brain.vault.name, p.notePath));
        break;
      case "accept-suggestion":
        if (p.suggestion && brain) await brain.createRoutine(p.suggestion);
        break;
      case "reject-suggestion":
        if (p.suggestion) updateSettings({ dismissedSuggestions: [...getSettings().dismissedSuggestions, p.suggestion.key] });
        break;
      case "close":
        break;
    }
  } catch (e) {
    log.warn("bubbleAction:", errorText(e));
  }
  scheduleSnapshot();
  setTimeout(tick, 1500); // si hay otro aviso en fila, que salga
}
