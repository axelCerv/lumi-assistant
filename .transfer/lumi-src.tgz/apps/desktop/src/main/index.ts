/** Lumi: proceso principal de Electron. */
import { app, Menu, nativeImage, shell, Tray } from "electron";
import path from "node:path";
import { loadSettings, getSettings } from "./settings";
import { loadState } from "./state";
import { loadSecrets } from "./secrets";
import { createWindows, hidePanel, markQuitting, send, setAvatarVisible, showPanel, showPanelView } from "./windows";
import { registerIpc } from "./ipc";
import { embedder, getBrain, openVault, scheduleSnapshot } from "./core";
import { startScheduler } from "./scheduler";
import { initUpdater } from "./updater";
import { log, errorText } from "./util";

app.setName("Lumi");
if (process.platform === "win32") app.setAppUserModelId("com.axelcervantes.lumi");

// Una sola copia de Lumi a la vez
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on("second-instance", () => {
    setAvatarVisible(true);
    showPanel();
  });
  app.whenReady().then(start).catch((e) => log.error("No pude iniciar:", errorText(e)));
}

let tray: Tray | null = null;

function resource(name: string): string {
  return app.isPackaged ? path.join(process.resourcesPath, name) : path.join(__dirname, "../../resources", name);
}

function buildTray(): void {
  const isMac = process.platform === "darwin";
  const img = nativeImage.createFromPath(resource(isMac ? "trayTemplate.png" : "tray.png"));
  if (isMac) img.setTemplateImage(true);
  tray = new Tray(img);
  tray.setToolTip("Lumi");
  const menu = Menu.buildFromTemplate([
    { label: "Abrir menú de Lumi", click: () => showPanel() },
    { label: "Cambiar el look de Lumi…", click: () => showPanelView("appearance") },
    { label: "Mostrar a Lumi", click: () => setAvatarVisible(true) },
    { label: "Esconder a Lumi", click: () => setAvatarVisible(false) },
    { type: "separator" },
    { label: "Abrir mi vault", click: () => void (getBrain() && shell.openPath(getBrain()!.vault.root)) },
    { type: "separator" },
    { label: "Salir de Lumi", click: () => app.quit() },
  ]);
  tray.setContextMenu(menu);
  if (!isMac) tray.on("click", () => showPanel());
}

async function start(): Promise<void> {
  loadSettings();
  loadState();
  loadSecrets();
  if (process.platform === "darwin") app.dock?.hide();

  registerIpc();
  createWindows();
  buildTray();

  // La ventana oculta calcula embeddings; aquí se conecta con el índice
  embedder.attach((id, texts) => send("brain", "brain-task", { id, texts }));

  const s = getSettings();
  if (s.vaultPath) await openVault(s.vaultPath);
  if (s.openAtLogin !== app.getLoginItemSettings().openAtLogin) app.setLoginItemSettings({ openAtLogin: s.openAtLogin, openAsHidden: true });

  startScheduler();
  initUpdater();
  scheduleSnapshot();
}

app.on("before-quit", () => {
  markQuitting();
  hidePanel();
  void getBrain()?.close();
});

// Lumi vive en la bandeja: no se cierra al cerrar ventanas
app.on("window-all-closed", () => {
  /* nada */
});
